package com.example.bang.myapplication;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.os.StrictMode;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Toast;


import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.utils.URLEncodedUtils;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.params.HttpConnectionParams;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

public class LoginActivity extends Activity {
    private EditText idInput;
    private EditText passwordInput;
    String loginId, loginPwd;

    private static String id = "";
    private static String pw = "";
    private static String msgString = null;
    private static boolean isConnected = false;

    int num=0;

    AlertDialogManager alert = new AlertDialogManager();

    // Session Manager Class
    SessionManager session;

    @SuppressLint("WrongViewCast")
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);

        // Session Manager
        session = new SessionManager(getApplicationContext());

        idInput = findViewById(R.id.idInput);
        passwordInput = findViewById(R.id.passwordInput);
        final Button loginButton = (Button) findViewById(R.id.loginButton);
        final Button signUpButton = findViewById(R.id.signUpButton);


        /**
         * 로그인 버튼 클릭
         */
        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                id = idInput.getText().toString();
                pw = passwordInput.getText().toString();

                new Handler().post(new Runnable() {
                    @Override
                    public void run() {
                        String url = "http://192.168.43.192:8080/web-study-02/user.jsp";
                        new LoginActivity().connect(url);

                        while (true) {
                            if (isConnected) {
                                session.createLoginSession(id, pw);
                                Toast.makeText(LoginActivity.this, msgString, Toast.LENGTH_LONG).show();
                                num=1;
                                Intent intent = new Intent(getApplicationContext(),MainActivity_menu.class);
                                intent.putExtra("test",num);
                                startActivity(intent);
                                break;
                            }
                        }
                    }
                });
                Intent i = new Intent(getApplicationContext(), MainActivity_menu.class);
                startActivity(i);
            }
        });


        signUpButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (v == signUpButton) {
                    Intent i1 = new Intent(getApplicationContext(), activity_join.class);
                    startActivity(i1);
                }

            }
        });

    }
    private void connect(String url){
        new WebConnection().execute(url);
    }

    private class WebConnection extends AsyncTask<String, Void, HttpResponse> {

        @Override
        protected HttpResponse doInBackground(String... urls) {
            HttpClient client = new DefaultHttpClient();
            HttpConnectionParams.setConnectionTimeout(client.getParams(), 10000);
            List<NameValuePair> params = new ArrayList<NameValuePair>();
            params.add(new BasicNameValuePair("id", id));
            params.add(new BasicNameValuePair("pwd", pw));

            Log.i("id", id);
            Log.i("pwd", pw);

            String url = urls[0] + "?" + URLEncodedUtils.format(params, "UTF-8");

            HttpGet httpGet = new HttpGet(url);
            HttpResponse response = null;
            String s = "";
            StringBuffer sb = null;
            try {
                response = client.execute(httpGet);
                HttpEntity entity = response.getEntity();
                InputStream is;
                BufferedReader br = null;
                if(entity != null) {
                    is = entity.getContent();
                    br = new BufferedReader(new InputStreamReader(is));
                    s = "";
                    sb = new StringBuffer();
                }
                while((s = br.readLine())!=null) {
                    sb.append(s);
                }
                Log.i("sb: ", sb.toString());
                msgString = sb.toString().trim().toString();
                Log.i("msgString: ", msgString);
                isConnected = true;
            } catch (Exception e) {
                e.printStackTrace();
            }
            return response;
        }


    }
}