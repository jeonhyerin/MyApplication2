package com.example.bang.myapplication;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity_unnine_sundae extends AppCompatActivity {

    TextView textView;
    TextView textView_1;
    TextView textView_price;
    int count2=0;
    String sundae_result = "";
    String sundae_count_total ="";
    String count1_str2="";
    String price_str2="";
    int test=0;
    int price=0;

    TextView beacon;
    TextView tv;
    Intent intent;

    private Button button1;

    public static String sundae_store_name;

    int total_num=0;

    CheckBox checkbox;
    String sundae_checkbox;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_unnine_sundae);

        TextView tv = (TextView)findViewById(R.id.total_menu);
        final String store_name = tv.getText().toString();

        final Intent main_name_intent = getIntent();
        sundae_store_name = main_name_intent.getStringExtra("store_name");

        final Intent beacon_intent = getIntent();
        final int beacon_distance = beacon_intent.getIntExtra("distance",0);


        final Context context = this;


        textView = (TextView) findViewById(R.id.count);
        textView_1 = (TextView)findViewById(R.id.name);
        textView_price = (TextView)findViewById(R.id.price);

        Button button_back = (Button)findViewById(R.id.button13);

        Button button_increse = (Button) findViewById(R.id.increse);
        Button button_decrese = (Button) findViewById(R.id.decrese);

        button_increse.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {

                switch (v.getId()) {
                    case R.id.increse:
                        count2++;
                        textView.setText("" + count2);
                        break;
                    default:
                        break;
                }
            }
        });

        button_decrese.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {

                switch (v.getId()) {
                    case R.id.decrese:
                        if (count2>0) {
                            count2--;
                            textView.setText("" + count2);
                        }
                        break;
                    default:
                        break;
                }
            }
        });

        button1 = (Button)findViewById(R.id.button_next);
        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                price = 3000*count2;
                price_str2 = Integer.toString(price);
                count1_str2 = Integer.toString(count2);
                if (count1_str2 == "0") {
                    Toast.makeText(MainActivity_unnine_sundae.this, "수량을 선택해 주세요", Toast.LENGTH_SHORT).show();
                }

                if (count1_str2 != "0") {
                    intent = new Intent(getApplicationContext(), MainActivity_shopping.class);
                    total_num=1;
                    test=2;
                    intent.putExtra("test",test);
                    intent.putExtra("total_num",total_num);
                    sundae_result += textView_1.getText().toString();
                    if (count2 !=0) {
                        sundae_count_total += count1_str2.toString()+"인분\n";
                    }

                    checkbox = (CheckBox) findViewById(R.id.checkBox2);
                    if (checkbox.isChecked()) sundae_checkbox = checkbox.getText().toString();
                    else sundae_checkbox = "추 가 없 음";

                    intent.putExtra("store",store_name);
                    intent.putExtra("s_name",sundae_result);
                    intent.putExtra("s_count",sundae_count_total);
                    intent.putExtra("s_price",price);
                    intent.putExtra("bool",true);
                    intent.putExtra("s_check",sundae_checkbox);
                    Toast.makeText(getApplicationContext(), "장바구니에 담겼습니다.", Toast.LENGTH_LONG).show();
                    startActivity(intent);

                    /*switch (v.getId()) {
                        case R.id.button_next:
                            AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(
                                    context);
                            // 제목셋팅
                            alertDialogBuilder.setTitle("알림");

                            // AlertDialog 셋팅
                            alertDialogBuilder
                                    .setMessage("장바구니로 이동하시겠습니까?")
                                    .setCancelable(false)
                                    .setPositiveButton("아니오",
                                            new DialogInterface.OnClickListener() {
                                                public void onClick(
                                                        DialogInterface dialog, int id) {
                                                    Toast.makeText(getApplicationContext(), "장바구니에 담겼습니다.", Toast.LENGTH_LONG).show();
                                                }
                                            })
                                    .setNegativeButton("예",
                                            new DialogInterface.OnClickListener() {
                                                public void onClick(
                                                        DialogInterface dialog, int id) {
                                                    startActivity(intent);
                                                }
                                            });

                            // 다이얼로그 생성
                            AlertDialog alertDialog = alertDialogBuilder.create();

                            // 다이얼로그 보여주기
                            alertDialog.show();
                            break;
                        default:
                            break;
                    }*/


                }


            }
        });


        Button button_shop = (Button)findViewById(R.id.botton_shop);
        button_shop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), MainActivity_shopping.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
                startActivity(intent);
            }
        });
    }
}
