package com.example.bang.myapplication;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ToggleButton;
import android.widget.ViewFlipper;

public class MainActivity_introduce extends AppCompatActivity {

    ViewFlipper flipper;
    //자동 Flipping 선택 ToggleButton 참조변수
    ToggleButton toggle_Flipping;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_introduce);
        flipper= (ViewFlipper)findViewById(R.id.flipper);

        Animation showIn= AnimationUtils.loadAnimation(this, android.R.anim.slide_in_left);

        //ViewFlipper에게 등장 애니메이션 적용

        flipper.setInAnimation(showIn);
        flipper.setOutAnimation(this, android.R.anim.slide_out_right);
        flipper.setFlipInterval(2000);//플리핑 간격(1000ms)
        flipper.startFlipping();

    }
}
