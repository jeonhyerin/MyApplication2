package com.example.bang.myapplication;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity_byuldabang extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_byuldabang);

        Button button1 = (Button)findViewById(R.id.coffee);
        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(),MainActivity_byuldabang_americano.class);
                startActivity(intent);
            }
        });

        Button button2 = (Button)findViewById(R.id.latte);
        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(),MainActivity_byuldabang_latte.class);
                startActivity(intent);
            }
        });
        Button button3 = (Button)findViewById(R.id.moca);
        button3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(),MainActivity_byuldabang_moca.class);
                startActivity(intent);
            }
        });

        Button button4 = (Button)findViewById(R.id.cappuccino);
        button4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(),MainActivity_byuldabang_cappuccino.class);
                startActivity(intent);
            }
        });

    }
}
