package com.example.bang.myapplication;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity_payment extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        final NotificationManager notificationManager =
                (NotificationManager) MainActivity_payment.this.getSystemService(MainActivity_payment.this.NOTIFICATION_SERVICE);
        final Intent intent = new Intent(getApplicationContext(), MainActivity_menu.class);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_payment);


        final Notification.Builder builder = new Notification.Builder(getApplicationContext());
        intent.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);


        Button button = (Button) findViewById(R.id.button_next);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //Snackbar.make(view, "푸시알림을 확인해주세요", Snackbar.LENGTH_LONG).setAction("Action", null).show();

                PendingIntent pendnoti = PendingIntent.getActivity(MainActivity_payment.this, 0, intent, PendingIntent.FLAG_UPDATE_CURRENT);
                //푸시 알림에 대한 각종 설정
                builder.setSmallIcon(R.drawable.ic_launcher_background).setTicker("Ticker")
                        .setWhen(System.currentTimeMillis()).setNumber(1)
                        .setContentTitle("새로운 주문/결제 내역이 들어왔습니다")
                        .setContentText("앱으로 확인해주세요!")
                        //.setDefaults(Notification.DEFAULT_SOUND | Notification.DEFAULT_VIBRATE)
                        .setContentIntent(pendnoti).setAutoCancel(true).setOngoing(true);
                notificationManager.notify(1, builder.build());
                startActivity(intent);
                /*Intent intent2 = new Intent(getApplicationContext(),MainActivity_ing.class);
                PendingIntent pending= PendingIntent.getActivity(getApplicationContext(), 1, intent2, PendingIntent.FLAG_UPDATE_CURRENT); //클릭하면 액티비티이동
                builder.setContentIntent(pending);   //PendingIntent 설정
                builder.setAutoCancel(true);         //클릭하면 자동으로 알림 삭제
                Notification notification= builder.build();    //Notification 객체 생성.notify(0, notification);    //NotificationManager가 알림(Notification)을 표시, id는 알림구분용

                notificationManager.notify(0,notification);*/

            }
        });
    }
}
