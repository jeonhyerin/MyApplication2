package com.example.bang.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;

import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.params.HttpParams;

import java.util.ArrayList;
import java.util.HashMap;

public class MainActivity_tool_of_payment extends AppCompatActivity {
    String btnValue, btnValue1, btnValue2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_tool_of_payment);

        SessionManager session = new SessionManager(getApplicationContext());
        HashMap<String, String> user = session.getUserDetails();

        final String id = user.get(SessionManager.KEY_ID);

        final String URL = "http://192.168.43.192:8080/web-study-02/list1_payment_1.jsp";
        final String URL1 = "http://192.168.43.192:8080/web-study-02/list1_payment_2.jsp";
        final String URL2 = "http://192.168.43.192:8080/web-study-02/list1_payment_3.jsp";

        final Button button1 = (Button)findViewById(R.id.button10);
        final Button button2 = (Button)findViewById(R.id.button11);
        final Button button3 = (Button)findViewById(R.id.button12);
        Intent intent = getIntent();
        final String togo = intent.getStringExtra("togo");

        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                btnValue = button1.getText().toString();
                HttpClient client = new DefaultHttpClient();
                HttpPost post = new HttpPost(URL);

                if(v == button1) {
                    try {
                        ArrayList<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>();
                        nameValuePairs.add(new BasicNameValuePair("cash", btnValue));
                        nameValuePairs.add(new BasicNameValuePair("togo", togo));
                        nameValuePairs.add(new BasicNameValuePair("id", id));
                        post.setEntity(new UrlEncodedFormEntity(nameValuePairs, "UTF-8"));

                        HttpParams params = client.getParams();

                        HttpResponse response = client.execute(post);
                    } catch (Exception e) {
                        e.printStackTrace();
                        client.getConnectionManager().shutdown();
                    }

                }
                Intent intent = new Intent(getApplicationContext(),MainActivity_payment.class);
                intent.putExtra("cash", btnValue);
                startActivity(intent);
            }
        });
        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                btnValue1 = button2.getText().toString();
                HttpClient client = new DefaultHttpClient();
                HttpPost post = new HttpPost(URL1);

                if(v == button2) {
                    try {
                        ArrayList<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>();
                        nameValuePairs.add(new BasicNameValuePair("card", btnValue1));
                        nameValuePairs.add(new BasicNameValuePair("togo", togo));
                        nameValuePairs.add(new BasicNameValuePair("id", id));
                        post.setEntity(new UrlEncodedFormEntity(nameValuePairs, "UTF-8"));

                        HttpParams params = client.getParams();

                        HttpResponse response = client.execute(post);
                    } catch (Exception e) {
                        e.printStackTrace();
                        client.getConnectionManager().shutdown();
                    }

                }
                Intent intent = new Intent(getApplicationContext(),MainActivity_payment.class);
                intent.putExtra("card", btnValue1);
                startActivity(intent);
            }
        });
        button3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                btnValue2 = button3.getText().toString();
                HttpClient client = new DefaultHttpClient();
                HttpPost post = new HttpPost(URL2);

                if(v == button3) {
                    try {
                        ArrayList<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>();
                        nameValuePairs.add(new BasicNameValuePair("voucher", btnValue2));
                        nameValuePairs.add(new BasicNameValuePair("togo", togo));
                        nameValuePairs.add(new BasicNameValuePair("id", id));
                        post.setEntity(new UrlEncodedFormEntity(nameValuePairs, "UTF-8"));

                        HttpParams params = client.getParams();

                        HttpResponse response = client.execute(post);
                    } catch (Exception e) {
                        e.printStackTrace();
                        client.getConnectionManager().shutdown();
                    }

                }
                Intent intent = new Intent(getApplicationContext(),MainActivity_payment.class);
                intent.putExtra("voucher", btnValue2);
                startActivity(intent);
            }
        });
    }
}
