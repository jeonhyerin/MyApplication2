package com.example.bang.myapplication;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity_sunmi extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_sunmi);

        Button button1 = (Button)findViewById(R.id.sundae_soup);
        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(),MainActivity_sunmi_danjangjjigae.class);
                startActivity(intent);
            }
        });
        Button button2 = (Button)findViewById(R.id.kimchi_sundae_soup);
        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(),MainActivity_sunmi_kimchijjigae.class);
                startActivity(intent);
            }
        });
        Button button3 = (Button)findViewById(R.id.cow_soup);
        button3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(),MainActivity_sunmi_budajjigae.class);
                startActivity(intent);
            }
        });
        Button button4 = (Button)findViewById(R.id.bone_soup);
        button4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(),MainActivity_sunmi_yukgaejang.class);
                startActivity(intent);
            }
        });
    }
}
