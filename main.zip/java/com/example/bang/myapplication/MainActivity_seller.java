package com.example.bang.myapplication;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.EditText;


public class MainActivity_seller extends Activity {
    WebView mWeb;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_seller);

        mWeb = (WebView)findViewById(R.id.web);
        //웹뷰 연결 부분
        mWeb.setWebViewClient(new MyWebClient());

        //웹뷰 설정 변경
        WebSettings set = mWeb.getSettings();
        //자바스크립트 사용가능하게함
        set.setJavaScriptEnabled(true);
        //+ - 크기조절 가능하게함.
        set.setBuiltInZoomControls(true);
        //아래것을해야 뒤로가기와 앞으로가기가 잘됨
        set.setCacheMode(WebSettings.LOAD_NO_CACHE);

        //첫페이지 설정

        mWeb.loadUrl("http://192.168.43.192:8080/fast-order-01/seller_login.jsp");

    }





    public void mOnClick(View v){
        switch(v.getId()){
            //에디트텍스트의 값을 읽어와서 그 웹페이지로 감
            case R.id.btngo:
                String url;
                EditText addr = (EditText)findViewById(R.id.address);
                url = addr.getText().toString();
                mWeb.loadUrl(url);
                break;

            //뒤로가기 버튼

            case R.id.btnback:
                if(mWeb.canGoBack()){
                    mWeb.goBack();
                }
                break;

            //앞으로가기 버튼

            case R.id.btnforward:
                if(mWeb.canGoForward()){
                    mWeb.goForward();
                }
        }
    }



    class MyWebClient extends WebViewClient{
        @Override
        public boolean shouldOverrideUrlLoading(WebView view, String url) {
            // TODO Auto-generated method stub
            view.loadUrl(url);//웹뷰가 url을 받도록 함
            return true;

        }
    }
}
