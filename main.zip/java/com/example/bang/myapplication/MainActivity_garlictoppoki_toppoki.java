package com.example.bang.myapplication;

import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity_garlictoppoki_toppoki extends AppCompatActivity {

    TextView textView;
    TextView textView_1;
    int count=0;
    String toppoki_result = "";
    String toppoki_count_total ="";
    String togo_result ="";
    String count1_str="";
    String price_str="";
    int test=0;
    int price=0;
    Intent intent2;
    Intent intent;
    Intent intent3;
    TextView tv;

    private Button button_increse;
    private Button button_decrese;
    private Button button1;

    ArrayList store;
    int total_num=0;
    CheckBox cheese;
    String cheese_check;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_garlictoppoki_toppoki);

        TextView tv = (TextView)findViewById(R.id.total_menu);
        final String store_name = tv.getText().toString();

        textView = (TextView) findViewById(R.id.count);
        textView_1 = (TextView) findViewById(R.id.name);

        Button button_back = (Button) findViewById(R.id.button13);

        button_increse = (Button) findViewById(R.id.increse);
        button_decrese = (Button) findViewById(R.id.decrese);

        button_increse.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                switch (v.getId()) {
                    case R.id.increse:
                        count++;
                        textView.setText("" + count);
                        break;
                    default:
                        break;
                }
            }
        });

        button_decrese.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                switch (v.getId()) {
                    case R.id.decrese:
                        if (count > 0) {
                            count--;
                            textView.setText("" + count);
                        }
                        break;
                    default:
                        break;
                }
            }
        });

        button1 = (Button) findViewById(R.id.button_next);
        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                total_num=1;
                test=11;
                price = 4000 * count;

                intent = new Intent(getApplicationContext(), MainActivity_shopping.class);

                count1_str = Integer.toString(count);
                //price_str = Integer.toString(price);
                //price_str = Integer.toString(3000*count);
                toppoki_result = textView_1.getText().toString() + "  ";
                if (count!=0) {
                    toppoki_count_total += count1_str.toString()+"인분\n";
                }
                if (count1_str == "0") {
                    Toast.makeText(MainActivity_garlictoppoki_toppoki.this, "수량을 선택해 주세요", Toast.LENGTH_SHORT).show();
                }

                if (count1_str != "0") {

                    cheese = (CheckBox) findViewById(R.id.checkBox2);
                    if (cheese.isChecked()) {
                        cheese_check = cheese.getText().toString();
                        price += 1000;
                    }
                    else cheese_check = "추 가 없 음";

                    intent = new Intent(getApplicationContext(), MainActivity_shopping.class);
                    intent.putExtra("total_num",total_num);
                    intent.putExtra("garlic_store",store_name);
                    intent.putExtra("garlic_name",toppoki_result);
                    intent.putExtra("garlic_count",toppoki_count_total);
                    intent.putExtra("garlic_check",cheese_check);
                    intent.putExtra("garlic_price",price);
                    intent.putExtra("bool",true);
                    Toast.makeText(getApplicationContext(), "장바구니에 담겼습니다.", Toast.LENGTH_LONG).show();
                    startActivity(intent);
                }

            }
        });



        Button button_shop = (Button)findViewById(R.id.botton_shop);
        button_shop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), MainActivity_shopping.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
                startActivity(intent);
            }
        });

    }
}
