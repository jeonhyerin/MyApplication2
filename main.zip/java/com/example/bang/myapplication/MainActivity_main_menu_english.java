package com.example.bang.myapplication;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity_main_menu_english extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_main_menu_english);

        Button search_button = (Button)findViewById(R.id.button_menu);
        search_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(),MainActivity_menu_english.class);
                startActivity(intent);
            }
        });

        Button intro_button = (Button)findViewById(R.id.button_intro);
        intro_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(),MainActivity_introduce_english.class);
                startActivity(intent);
            }
        });
        Button mypage_button = (Button)findViewById(R.id.button_mypage);
        mypage_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(),MainActivity_mypage_english.class);
                startActivity(intent);
            }
        });
    }
}
