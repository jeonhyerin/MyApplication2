package com.example.bang.myapplication;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.params.HttpParams;

import java.util.ArrayList;
import java.util.HashMap;

public class MainActivity_unnine extends AppCompatActivity {
    String btnValue, btnValue1, btnValue2, btnValue3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_unnine);

        SessionManager session = new SessionManager(getApplicationContext());
        HashMap<String, String> user = session.getUserDetails();

        final String id = user.get(SessionManager.KEY_ID);



        final Button b1 = (Button)findViewById(R.id.toppoki);
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(),MainActivity_unnine_toppoki.class);
                startActivity(intent);
            }
        });

        final Button b2 = (Button)findViewById(R.id.sundae);
        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(),MainActivity_unnine_sundae.class);
                startActivity(intent);
            }
        });


        final Button b3 = (Button)findViewById(R.id.friedfood);
        b3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(),MainActivity_unnine_fried_food.class);
                startActivity(intent);
            }
        });
        final Button b4 = (Button)findViewById(R.id.ricefish);
        b4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(),MainActivity_unnine_fishcake.class);
                startActivity(intent);
            }
        });
    }
}
