package com.example.bang.myapplication;


import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.estimote.sdk.Beacon;
import com.estimote.sdk.BeaconManager;
import com.estimote.sdk.Region;
import com.estimote.sdk.SystemRequirementsChecker;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class MainActivity_close_store extends AppCompatActivity {


    public static BeaconManager beaconManager;
    public static Region region;
    public static TextView tv;
    public static Beacon nearestBeacon;
    public static int num;
    public static int beacon_distance = 0;

    public static BeaconManager beaconManager2;
    public static Beacon nearestBeacon2;
    public static Region region2;
    public static TextView beacon_test;
    public static TextView beacon_test2;
    public static TextView beacon_test3;
    public static List<String> list1 = new ArrayList<>();
    public static ArrayAdapter<String> adapter;
    public static ListView listview1;
    public static RelativeLayout r1;
    public static Button button_back;

    public static BeaconManager beaconManager3;
    public static Beacon nearestBeacon3;
    public static Region region3;

    public static BeaconManager beaconManager4;
    public static Beacon nearestBeacon4;
    public static Region region4;

    public static BeaconManager beaconManager5;
    public static Beacon nearestBeacon5;
    public static Region region5;

    public static BeaconManager beaconManager6;
    public static Beacon nearestBeacon6;
    public static Region region6;

    public static String str;
    public static String main="";
    public static String main2="";
    public static String main3="";
    public static String main4="";
    public static String main5="";
    public static String main6="";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_close_store);

        beacon_distance();
        beacon_distance2();
        beacon_distance3();
        beacon_distance4();
        beacon_distance5();
        beacon_distance6();

        listview1 = (ListView) findViewById(R.id.listview1);
        //리스트뷰와 리스트를 연결하기 위해 사용되는 어댑터
        adapter = new ArrayAdapter<String>
                (this, android.R.layout.simple_list_item_1, list1)
        {
            @Override
            public View getView(int position, View convertView, ViewGroup parent)
            {
                View view = super.getView(position, convertView, parent);
                TextView tv = (TextView) view.findViewById(android.R.id.text1);
                tv.setTextSize(20);  //텍스트 사이즈
                tv.setGravity(Gravity.CENTER);
                return view;
            }
        };

        //리스트뷰의 어댑터를 지정해준다.
        listview1.setAdapter(adapter);

        /*beacon_test = (TextView) findViewById(R.id.beacon_test);
        beacon_test2 = (TextView) findViewById(R.id.beacon_test2);
        beacon_test3 = (TextView)findViewById(R.id.beacon_test3);*/

        r1 = (RelativeLayout) findViewById(R.id.r1);

        listview1.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view,
                                    int position, long id) {
                str = (String) parent.getAdapter().getItem(position);

                if (str == "언 니 네") {
                    Intent intent = new Intent(
                            getApplicationContext(), // 현재화면의 제어권자
                            MainActivity_unnine.class); // 다음넘어갈 화면
                    /*main = str.toString();
                    intent.putExtra("name",main);*/
                    startActivity(intent);
                }
                if (str == "태 평 순 대") {
                    Intent intent2 = new Intent(
                            getApplicationContext(), // 현재화면의 제어권자
                            MainActivity_taepyung_sundae.class); // 다음넘어갈 화면
                    /*main2 = str.toString();
                    intent2.putExtra("name",main2);*/
                    startActivity(intent2);
                }
                if (str == "리 라 네 분 식") {
                    Intent intent3 = new Intent(
                            getApplicationContext(), // 현재화면의 제어권자
                            MainActivity_lilane.class); // 다음넘어갈 화면
                    /*main3 = str.toString();
                    intent3.putExtra("name",main3);*/
                    startActivity(intent3);
                }
                if (str == "별 다 방") {
                    Intent intent3 = new Intent(
                            getApplicationContext(), // 현재화면의 제어권자
                            MainActivity_byuldabang.class); // 다음넘어갈 화면
                    startActivity(intent3);
                }
                if (str == "한 양 정 육 점") {
                    Intent intent3 = new Intent(
                            getApplicationContext(), // 현재화면의 제어권자
                            MainActivity_hanyang.class); // 다음넘어갈 화면
                    startActivity(intent3);
                }
                if (str == "싱 싱 청 과 물") {
                    Intent intent3 = new Intent(
                            getApplicationContext(), // 현재화면의 제어권자
                            MainActivity_singsing.class); // 다음넘어갈 화면
                    startActivity(intent3);
                }
            }
        });

    }

    public void beacon_distance(){
        beaconManager = new BeaconManager(this);
        beaconManager.setRangingListener(new BeaconManager.RangingListener() {
            @Override
            public void onBeaconsDiscovered(Region region, List<Beacon> list) {
                if (!list.isEmpty()) {
                    nearestBeacon = list.get(0);
                    Log.d("Airport", "Nearest places:" + nearestBeacon.getRssi());
                    SharedPreferences distance = getSharedPreferences("distance", MODE_PRIVATE);
                    SharedPreferences.Editor editor = distance.edit();
                    editor.putInt("beacon_distance", nearestBeacon.getRssi());
                    editor.commit();
                    //beacon_test.setText("언니네: " + nearestBeacon.getRssi() + "");
                    if (nearestBeacon.getRssi() > -75) {
                        beacon_distance = nearestBeacon.getRssi();
                        if (!list1.contains("언 니 네")) {
                            adapter.add("언 니 네");
                        }
                        r1.setVisibility(View.VISIBLE);
                        num = 1;
                        Intent beacon_intent = new Intent();
                        beacon_intent.putExtra(Intent.EXTRA_TEXT, beacon_distance);
                    } else if (nearestBeacon.getRssi() <= -75) {
                        int count;
                        count = adapter.getCount();
                        if (count > 0) {
                            // 현재 선택된 아이템의 position 획득.
                            adapter.remove("언 니 네");
                            // listview 선택 초기화.
                            listview1.clearChoices();
                            // listview 갱신.
                            adapter.notifyDataSetChanged();
                        }

                        r1.setVisibility(View.GONE);
                        num = 0;
                    }
                }
            }

        });
        region = new Region("ranged region",
                UUID.fromString("E2C56DB5-DFFB-48D2-B060-D0F5A71096E0"), 40001, 16978);
    }

    public void beacon_distance2(){
        beaconManager2 = new BeaconManager(this);
        beaconManager2.setRangingListener(new BeaconManager.RangingListener() {
            @Override
            public void onBeaconsDiscovered(Region region, List<Beacon> list2) {
                if (!list2.isEmpty()) {
                    nearestBeacon2 = list2.get(0);
                    Log.d("Airport", "Nearest places:" + nearestBeacon2.getRssi());
                    //beacon_test2.setText("태평순대: " + nearestBeacon2.getRssi() + "");
                    if (nearestBeacon2.getRssi() > -75) {
                        if (!list1.contains("태 평 순 대")) {
                            adapter.add("태 평 순 대");
                        }
                        num = 1;
                    } else if (nearestBeacon2.getRssi() <= -75) {
                        int count, checked;
                        count = adapter.getCount();
                        if (count > 0) {
                            // 현재 선택된 아이템의 position 획득.
                            adapter.remove("태 평 순 대");
                            // listview 선택 초기화.
                            listview1.clearChoices();
                            // listview 갱신.
                            adapter.notifyDataSetChanged();
                        }
                        //r1.setVisibility(View.GONE);
                        num = 0;
                        //beacon.setText(" ");
                    }
                }
            }
        });
        region2 = new Region("ranged region",
                UUID.fromString("E2C56DB5-DFFB-48D2-B060-D0F5A71096E0"), 40001, 20013);
    }

    public void beacon_distance3() {

        beaconManager3 = new BeaconManager(this);
        beaconManager3.setRangingListener(new BeaconManager.RangingListener() {
            @Override
            public void onBeaconsDiscovered(Region region, List<Beacon> list3) {
                if (!list3.isEmpty()) {
                    nearestBeacon3 = list3.get(0);
                    Log.d("Airport", "Nearest places:" + nearestBeacon3.getRssi());
                    SharedPreferences distance = getSharedPreferences("distance", MODE_PRIVATE);
                    SharedPreferences.Editor editor = distance.edit();
                    editor.putInt("beacon_distance", nearestBeacon3.getRssi());
                    editor.commit();
                    //beacon_test3.setText("리라네분식: " + nearestBeacon3.getRssi() + "");
                    if (nearestBeacon3.getRssi() > -75) {
                        if (!list1.contains("리 라 네 분 식")) {
                            adapter.add("리 라 네 분 식");
                        }
                        num = 1;
                        // b.setVisibility(View.VISIBLE);
                    } else if (nearestBeacon3.getRssi() <= -75) {
                        int count, checked;
                        count = adapter.getCount();
                        if (count > 0) {
                            // 현재 선택된 아이템의 position 획득.
                            adapter.remove("리 라 네 분 식");
                            // listview 선택 초기화.
                            listview1.clearChoices();
                            // listview 갱신.
                            adapter.notifyDataSetChanged();
                        }

                        r1.setVisibility(View.GONE);
                        num = 0;
                    }
                }
            }

        });
        region3 = new Region("ranged region",
                UUID.fromString("E2C56DB5-DFFB-48D2-B060-D0F5A71096E0"), 40001, 15306);

    }

    public void beacon_distance4() {

        beaconManager4 = new BeaconManager(this);
        beaconManager4.setRangingListener(new BeaconManager.RangingListener() {
            @Override
            public void onBeaconsDiscovered(Region region, List<Beacon> list4) {
                if (!list4.isEmpty()) {
                    nearestBeacon4 = list4.get(0);
                    Log.d("Airport", "Nearest places:" + nearestBeacon4.getRssi());
                    SharedPreferences distance = getSharedPreferences("distance", MODE_PRIVATE);
                    SharedPreferences.Editor editor = distance.edit();
                    editor.putInt("beacon_distance", nearestBeacon4.getRssi());
                    editor.commit();
                    //beacon_test3.setText("리라네분식: " + nearestBeacon3.getRssi() + "");
                    if (nearestBeacon4.getRssi() > -75) {
                        if (!list1.contains("별 다 방")) {
                            adapter.add("별 다 방");
                        }
                        num = 1;
                        // b.setVisibility(View.VISIBLE);
                    } else if (nearestBeacon4.getRssi() <= -75) {
                        int count, checked;
                        count = adapter.getCount();
                        if (count > 0) {
                            // 현재 선택된 아이템의 position 획득.
                            adapter.remove("별 다 방");
                            // listview 선택 초기화.
                            listview1.clearChoices();
                            // listview 갱신.
                            adapter.notifyDataSetChanged();
                        }

                        r1.setVisibility(View.GONE);
                        num = 0;
                    }
                }
            }

        });
        region4 = new Region("ranged region",
                UUID.fromString("E2C56DB5-DFFB-48D2-B060-D0F5A71096E0"), 40001, 20002);

    }

    public void beacon_distance5() {

        beaconManager5 = new BeaconManager(this);
        beaconManager5.setRangingListener(new BeaconManager.RangingListener() {
            @Override
            public void onBeaconsDiscovered(Region region, List<Beacon> list5) {
                if (!list5.isEmpty()) {
                    nearestBeacon5 = list5.get(0);
                    Log.d("Airport", "Nearest places:" + nearestBeacon5.getRssi());
                    SharedPreferences distance = getSharedPreferences("distance", MODE_PRIVATE);
                    SharedPreferences.Editor editor = distance.edit();
                    editor.putInt("beacon_distance", nearestBeacon5.getRssi());
                    editor.commit();
                    //beacon_test3.setText("리라네분식: " + nearestBeacon3.getRssi() + "");
                    if (nearestBeacon5.getRssi() > -75) {
                        if (!list1.contains("한 양 정 육 점")) {
                            adapter.add("한 양 정 육 점");
                        }
                        num = 1;
                        // b.setVisibility(View.VISIBLE);
                    } else if (nearestBeacon5.getRssi() <= -75) {
                        int count, checked;
                        count = adapter.getCount();
                        if (count > 0) {
                            // 현재 선택된 아이템의 position 획득.
                            adapter.remove("한 양 정 육 점");
                            // listview 선택 초기화.
                            listview1.clearChoices();
                            // listview 갱신.
                            adapter.notifyDataSetChanged();
                        }

                        r1.setVisibility(View.GONE);
                        num = 0;
                    }
                }
            }

        });
        region5 = new Region("ranged region",
                UUID.fromString("E2C56DB5-DFFB-48D2-B060-D0F5A71096E0"), 40001, 16977);

    }

    public void beacon_distance6() {

        beaconManager6 = new BeaconManager(this);
        beaconManager6.setRangingListener(new BeaconManager.RangingListener() {
            @Override
            public void onBeaconsDiscovered(Region region, List<Beacon> list6) {
                if (!list6.isEmpty()) {
                    nearestBeacon6 = list6.get(0);
                    Log.d("Airport", "Nearest places:" + nearestBeacon6.getRssi());
                    SharedPreferences distance = getSharedPreferences("distance", MODE_PRIVATE);
                    SharedPreferences.Editor editor = distance.edit();
                    editor.putInt("beacon_distance", nearestBeacon6.getRssi());
                    editor.commit();
                    //beacon_test3.setText("리라네분식: " + nearestBeacon3.getRssi() + "");
                    if (nearestBeacon6.getRssi() > -75) {
                        if (!list1.contains("싱 싱 청 과 물")) {
                            adapter.add("싱 싱 청 과 물");
                        }
                        num = 1;
                        // b.setVisibility(View.VISIBLE);
                    } else if (nearestBeacon6.getRssi() <= -75) {
                        int count, checked;
                        count = adapter.getCount();
                        if (count > 0) {
                            // 현재 선택된 아이템의 position 획득.
                            adapter.remove("싱 싱 청 과 물");
                            // listview 선택 초기화.
                            listview1.clearChoices();
                            // listview 갱신.
                            adapter.notifyDataSetChanged();
                        }

                        r1.setVisibility(View.GONE);
                        num = 0;
                    }
                }
            }

        });
        region6 = new Region("ranged region",
                UUID.fromString("E2C56DB5-DFFB-48D2-B060-D0F5A71096E0"), 40001, 16933);

    }


    @Override
    protected void onResume() {
        super.onResume();
        SystemRequirementsChecker.checkWithDefaultDialogs(this);

        beaconManager.connect(new BeaconManager.ServiceReadyCallback() {
            @Override
            public void onServiceReady() {
                beaconManager.startRanging(region);

            }
        });
        beaconManager2.connect(new BeaconManager.ServiceReadyCallback() {
            @Override
            public void onServiceReady() {
                beaconManager2.startRanging(region2);

            }
        });
        beaconManager3.connect(new BeaconManager.ServiceReadyCallback() {
            @Override
            public void onServiceReady() {
                beaconManager3.startRanging(region3);

            }
        });
        beaconManager4.connect(new BeaconManager.ServiceReadyCallback() {
            @Override
            public void onServiceReady() {
                beaconManager4.startRanging(region4);

            }
        });
        beaconManager5.connect(new BeaconManager.ServiceReadyCallback() {
            @Override
            public void onServiceReady() {
                beaconManager5.startRanging(region5);

            }
        });
        beaconManager6.connect(new BeaconManager.ServiceReadyCallback() {
            @Override
            public void onServiceReady() {
                beaconManager6.startRanging(region6);

            }
        });
    }


}
