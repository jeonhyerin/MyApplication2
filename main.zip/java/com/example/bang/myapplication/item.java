package com.example.bang.myapplication;

import android.view.View;

public class item
{
    public String strTitle;
    public String strDate;

}