package com.example.bang.myapplication;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.StrictMode;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.SparseBooleanArray;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.params.HttpParams;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class MainActivity_shopping_english extends AppCompatActivity {

    Intent intent2;
    public static ListView listview1;
    public static ArrayAdapter<String> adapter;
    public static List<String> list1 = new ArrayList<>();
    public static ArrayList<item> oData = new ArrayList<>();
    public static item oItem;
    public static ListAdapter2 oAdapter;
    public static Button delete_button;
    public static Button deleteall_button;
    int num = 0;
    SharedPreferences food;
    SharedPreferences s_food;
    SharedPreferences pork;
    SharedPreferences bulgogi;
    SharedPreferences cabbage;
    SharedPreferences lettuce;
    public static List<Integer> price_list = new ArrayList<>();
    int t1 = 0;
    int t = 0;
    public static int total_price;
    public static boolean bool = false;
    public static SparseBooleanArray check;

    int price;
    int hanyang_price;
    int hanyang_beef_price;
    int hanyang_bul_price;
    int hanyang_chicken_price;
    int singsing_cabbage_price;
    int singsing_cucumber_price;
    int singsing_lettuce_price;
    int singsing_raddish_price;

    String btn_checked;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_shopping_english);

        if (Build.VERSION.SDK_INT > 9) {
            StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
            StrictMode.setThreadPolicy(policy);

        }

        SessionManager session = new SessionManager(getApplicationContext());
        HashMap<String, String> user = session.getUserDetails();

        Intent intent = getIntent();

        final ArrayList<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>();
        final String id = user.get(SessionManager.KEY_ID);

        final TextView textView_price = (TextView) findViewById(R.id.price);
        int total_num = intent.getIntExtra("total_num", 0);
        bool = intent.getBooleanExtra("bool", false);

        final CheckBox checkBox = (CheckBox) findViewById(R.id.checkBox4); // 전체포장


        checkBox.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Checked(v);
                btn_checked = Checked(v);
            }
        });
        String singsing_store_name = intent.getStringExtra("singsing_store");
        String singsing_cabbage_name = intent.getStringExtra("singsing_cabbage_name");
        String singsing_cabbage_count = intent.getStringExtra("singsing_cabbage_count");
        singsing_cabbage_price = intent.getIntExtra("singsing_cabbage_price", 0);

        String singsing_lettuce_name = intent.getStringExtra("singsing_lettuce_name");
        String singsing_lettuce_count = intent.getStringExtra("singsing_lettuce_count");
        singsing_lettuce_price = intent.getIntExtra("singsing_lettuce_price", 0);

        String hanyang_store_name = intent.getStringExtra("hanyang_store");
        String hanyang_name = intent.getStringExtra("hanyang_name");
        String hanyang_count = intent.getStringExtra("hanyang_count");
        hanyang_price = intent.getIntExtra("hanyang_price", 0);

        String hanyang_bul_name = intent.getStringExtra("hanyang_bul_name");
        String hanyang_bul_count = intent.getStringExtra("hanyang_bul_count");
        hanyang_bul_price = intent.getIntExtra("hanyang_bul_price", 0);


        listview1 = (ListView) findViewById(R.id.listview1);
        oAdapter = new ListAdapter2(oData);
        listview1.setAdapter(oAdapter);
        oItem = new item();

        if (bool == true) {
            if (hanyang_name != null && total_num==1){
                oItem.strTitle = hanyang_store_name;
                oItem.strDate = hanyang_name + hanyang_count;
                price_list.add(hanyang_price);
                oData.add(oItem);


                String hanyang_price1 = Integer.toString(hanyang_price);
                final String URL = "http://192.168.43.192:8080/web-study-02/list1_groceries1_1_english.jsp";

                HttpClient client = new DefaultHttpClient();
                HttpPost post = new HttpPost(URL);

                try {
                    nameValuePairs.add(new BasicNameValuePair("hanyang", hanyang_store_name));
                    nameValuePairs.add(new BasicNameValuePair("pork", hanyang_name));
                    nameValuePairs.add(new BasicNameValuePair("price", hanyang_price1));
                    nameValuePairs.add(new BasicNameValuePair("count", hanyang_count));


                    nameValuePairs.add(new BasicNameValuePair("id", id));
                    post.setEntity(new UrlEncodedFormEntity(nameValuePairs, "UTF-8"));

                    HttpParams params = client.getParams();

                    HttpResponse response = client.execute(post);
                } catch (Exception e) {
                    e.printStackTrace();
                    client.getConnectionManager().shutdown();
                }
            }
            if (hanyang_bul_name != null && total_num==1){
                oItem.strTitle = hanyang_store_name;
                oItem.strDate = hanyang_bul_name + hanyang_bul_count;
                price_list.add(hanyang_bul_price);
                oData.add(oItem);

                String hanyang_bul_price1 = Integer.toString(hanyang_bul_price);
                final String URL1 = "http://192.168.43.192:8080/web-study-02/list1_groceries1_1_english.jsp";

                HttpClient client = new DefaultHttpClient();
                HttpPost post = new HttpPost(URL1);

                try {
                    nameValuePairs.add(new BasicNameValuePair("hanyang", hanyang_store_name));
                    nameValuePairs.add(new BasicNameValuePair("bulgogi", hanyang_bul_name));
                    nameValuePairs.add(new BasicNameValuePair("bul_price", hanyang_bul_price1));
                    nameValuePairs.add(new BasicNameValuePair("bul_count", hanyang_bul_count));

                    nameValuePairs.add(new BasicNameValuePair("id", id));
                    post.setEntity(new UrlEncodedFormEntity(nameValuePairs, "UTF-8"));

                    HttpParams params = client.getParams();

                    HttpResponse response = client.execute(post);
                } catch (Exception e) {
                    e.printStackTrace();
                    client.getConnectionManager().shutdown();
                }
            }
            if (singsing_cabbage_name != null && total_num==1){
                oItem.strTitle = singsing_store_name;
                oItem.strDate = singsing_cabbage_name + singsing_cabbage_count;
                price_list.add(singsing_cabbage_price);
                oData.add(oItem);

                String singsing_cabbage_price1 = Integer.toString(singsing_cabbage_price);
                final String URL2 = "http://192.168.43.192:8080/web-study-02/list1_groceries2_english.jsp";

                HttpClient client = new DefaultHttpClient();
                HttpPost post = new HttpPost(URL2);

                try {
                    nameValuePairs.add(new BasicNameValuePair("singsing", singsing_store_name));
                    nameValuePairs.add(new BasicNameValuePair("cabbage", singsing_cabbage_name));
                    nameValuePairs.add(new BasicNameValuePair("price", singsing_cabbage_price1));
                    nameValuePairs.add(new BasicNameValuePair("count", singsing_cabbage_count));
                    nameValuePairs.add(new BasicNameValuePair("id", id));
                    post.setEntity(new UrlEncodedFormEntity(nameValuePairs, "UTF-8"));

                    HttpParams params = client.getParams();

                    HttpResponse response = client.execute(post);
                } catch (Exception e) {
                    e.printStackTrace();
                    client.getConnectionManager().shutdown();
                }
            }
            if (singsing_lettuce_name != null && total_num==1){
                oItem.strTitle = singsing_store_name;
                oItem.strDate =singsing_lettuce_name + singsing_lettuce_count;
                price_list.add(singsing_lettuce_price);
                oData.add(oItem);

                String singsing_lettuce_price1 = Integer.toString(singsing_lettuce_price);
                final String URL3 = "http://192.168.43.192:8080/web-study-02/list1_groceries2_english.jsp";

                HttpClient client = new DefaultHttpClient();
                HttpPost post = new HttpPost(URL3);

                try {
                    nameValuePairs.add(new BasicNameValuePair("singsing", singsing_store_name));
                    nameValuePairs.add(new BasicNameValuePair("lettuce", singsing_lettuce_name));
                    nameValuePairs.add(new BasicNameValuePair("l_price", singsing_lettuce_price1));
                    nameValuePairs.add(new BasicNameValuePair("l_count", singsing_lettuce_count));
                    nameValuePairs.add(new BasicNameValuePair("id", id));
                    post.setEntity(new UrlEncodedFormEntity(nameValuePairs, "UTF-8"));

                    HttpParams params = client.getParams();

                    HttpResponse response = client.execute(post);
                } catch (Exception e) {
                    e.printStackTrace();
                    client.getConnectionManager().shutdown();
                }
            }

            if (total_price == 0) {
                total_price += price_list.get(0);
            } else {
                total_price += price_list.get(price_list.size() - 1);
            }
            super.onBackPressed();
        } else {
            textView_price.setText("subtotal : " +total_price);
            Button button_back = (Button) findViewById(R.id.button13);
            Button button1 = (Button) findViewById(R.id.button_next); //결제버튼
            button1.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (oData.size() == 0){
                        Toast.makeText(MainActivity_shopping_english.this, "CART IS EMPTY. PLEASE PUT THE ITEM!", Toast.LENGTH_SHORT).show();
                    }
                    else {
                        intent2 = new Intent(getApplicationContext(), MainActivity_tool_of_payment_english.class);
                        intent2.putExtra("togo", btn_checked);
                        startActivity(intent2);
                    }
                }
            });

        }

        deleteall_button = (Button) findViewById(R.id.deleteall);
        deleteall_button.setOnClickListener(new Button.OnClickListener() {
            public void onClick(View v) {
                oData.clear();
                listview1.setAdapter(null);
                total_price = 0;
                price_list.clear();
                textView_price.setText("subtotal :" +total_price);
                Toast.makeText(MainActivity_shopping_english.this, "delete", Toast.LENGTH_SHORT).show();
                // 모든 선택 상태 초기화.
                listview1.clearChoices();
                oAdapter.notifyDataSetChanged();
            }
        });

    }
    public String Checked(View v) {
        CheckBox checkBox1 = (CheckBox) findViewById(R.id.checkBox4);

        String resultText = "";
        if(checkBox1.isChecked()) {
            resultText = "전체포장";
        }

        return resultText;
    }
}
