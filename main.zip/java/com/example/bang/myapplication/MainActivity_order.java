package com.example.bang.myapplication;

import android.os.AsyncTask;
import android.os.Build;
import android.os.StrictMode;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.params.HttpParams;
import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;

import static com.example.bang.myapplication.SessionManager.*;

public class MainActivity_order extends AppCompatActivity {
    ListView lv;
    ArrayList<String> nameArr;
    ArrayAdapter<String> adapter;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_order);

        if (Build.VERSION.SDK_INT > 9) {
            StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
            StrictMode.setThreadPolicy(policy);

        }
        SessionManager session = new SessionManager(getApplicationContext());
        HashMap<String, String> user = session.getUserDetails();

        final ArrayList<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>();
        final String id = user.get(SessionManager.KEY_ID);

        nameArr=new ArrayList<String>();

        //JSP연동.json파싱해서 ArrayList에 추가
        String url="http://192.168.43.192:8080/web-study-02/example.jsp" + "?id="+ id;

        lv=(ListView)findViewById(R.id.listView);
        //리스트뷰와 리스트를 연결하기 위해 사용되는 어댑터
        adapter = new ArrayAdapter<String>
                (this, android.R.layout.simple_list_item_1, nameArr)
        {
            @Override
            public View getView(int position, View convertView, ViewGroup parent)
            {
                View view = super.getView(position, convertView, parent);
                TextView tv = (TextView) view.findViewById(android.R.id.text1);
                tv.setTextSize(30);  //텍스트 사이즈
                tv.setGravity(Gravity.CENTER);
                return view;
            }
        };

        lv.setAdapter(adapter);

        //AsyncTask실행
        new DownloadWebpageTask().execute(url);
    }


    private class DownloadWebpageTask extends AsyncTask<String,Void,String> {
        SessionManager session = new SessionManager(getApplicationContext());
        HashMap<String, String> user = session.getUserDetails();
        String id = user.get(SessionManager.KEY_ID);
        //주요 내용 실행
        @Override
        protected String doInBackground(String... urls) {
            try {
                return (String)downloadUrl((String)urls[0]);
            } catch (IOException e) {
                return "다운로드 실패";
            }
        }

        private String downloadUrl(String myurl) throws IOException {

            HttpURLConnection conn = null;
            try {
                URL url = new URL(myurl);
                conn = (HttpURLConnection) url.openConnection();

                BufferedInputStream buf = new BufferedInputStream(conn.getInputStream());
                BufferedReader bufreader = new BufferedReader(new InputStreamReader(buf, "utf-8"));
                String line = null;
                String page = "";
                while((line = bufreader.readLine()) != null) {
                    page += line;
                }

                return page;
            } finally {
                conn.disconnect();
            }
        }

        //ui변경 작업 실행
        @Override
        protected void onPostExecute(String result) {
            try {
                JSONObject json = new JSONObject(result);
                JSONArray jArr = json.getJSONArray("order_pay");

                for (int i=0; i<jArr.length(); i++) {
                    json = jArr.getJSONObject(i);
                    String menu = json.getString("order_menu");
                    String place = json.getString("order_place");
                    int price = json.getInt("order_price");
                    String price1 = String.valueOf(price);
                    int amount = json.getInt("order_amount");
                    String amount1 = String.valueOf(amount);
                    String time = json.getString("order_time");
                    String total = "주문메뉴:" + menu + "\n"+"주문장소:"+ place + "\n" + "주문가격:" + price1 + "\n" +"주문수량:"+ amount1 + "\n" + "주문시간: " +time;
                    //name을 ArrayList에 추가
                    nameArr.add(total);
                    adapter.notifyDataSetChanged();//변경내용 반영
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
}

