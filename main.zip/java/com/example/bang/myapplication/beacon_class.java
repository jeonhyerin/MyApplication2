package com.example.bang.myapplication;

import android.app.Application;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import com.estimote.sdk.Beacon;
import com.estimote.sdk.BeaconManager;
import com.estimote.sdk.Region;
import java.util.List;
import java.util.UUID;

public class beacon_class extends Application {
    private BeaconManager beaconManager;
    private BeaconManager beaconManager2;
    private BeaconManager beaconManager3;
    int beacon_distance =0;
    @Override
    public void onCreate() {
        super.onCreate();
        beaconManager = new BeaconManager(getApplicationContext());
        beaconManager.connect(new BeaconManager.ServiceReadyCallback(){
            @Override
            public void onServiceReady(){
                beaconManager.startMonitoring(new Region(
                        "monitored region",
                        UUID.fromString("E2C56DB5-DFFB-48D2-B060-D0F5A71096E0"),
                        40001,20002));
            }
        });

        beaconManager.setMonitoringListener(new BeaconManager.MonitoringListener() {
            @Override
            public void onEnteredRegion(Region region, List<Beacon> list) {
                showNotification("들어옴","비콘 연결됨"+list.get(0).getRssi());
                //getApplicationContext().startActivity(new Intent(getApplicationContext(), PopupActivxity.class).putExtra("uuid", String.valueOf(list.get(0).getProximityUUID()) ).setFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
            }

            @Override
            public void onExitedRegion(Region region) {
                showNotification("나감", "비콘 연결끊김");
            }
        });

        beaconManager2 = new BeaconManager(getApplicationContext());
        beaconManager2.connect(new BeaconManager.ServiceReadyCallback(){
            @Override
            public void onServiceReady(){
                beaconManager2.startMonitoring(new Region(
                        "monitored region",
                        UUID.fromString("E2C56DB5-DFFB-48D2-B060-D0F5A71096E0"),
                        40001,20013));
    }
});


        beaconManager2.setMonitoringListener(new BeaconManager.MonitoringListener() {
        @Override
        public void onEnteredRegion(Region region, List<Beacon> list2) {
            showNotification("들어옴2","비콘 연결됨2"+list2.get(0).getRssi());
            //getApplicationContext().startActivity(new Intent(getApplicationContext(), PopupActivxity.class).putExtra("uuid", String.valueOf(list.get(0).getProximityUUID()) ).setFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
        }

            @Override
            public void onExitedRegion(Region region) {
                showNotification("나감2", "비콘 연결끊김2");
            }


        });
        beaconManager3 = new BeaconManager(getApplicationContext());
        beaconManager3.connect(new BeaconManager.ServiceReadyCallback(){
            @Override
            public void onServiceReady(){
                beaconManager3.startMonitoring(new Region(
                        "monitored region",
                        UUID.fromString("E2C56DB5-DFFB-48D2-B060-D0F5A71096E0"),
                        40001,15306));
            }
        });


        beaconManager3.setMonitoringListener(new BeaconManager.MonitoringListener() {
            @Override
            public void onEnteredRegion(Region region, List<Beacon> list3) {
                showNotification("들어옴3","비콘 연결됨3"+list3.get(0).getRssi());
                //getApplicationContext().startActivity(new Intent(getApplicationContext(), PopupActivxity.class).putExtra("uuid", String.valueOf(list.get(0).getProximityUUID()) ).setFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
            }

            @Override
            public void onExitedRegion(Region region) {
                showNotification("나감3", "비콘 연결끊김3");
            }


        });


    }

    public void showNotification(String title, String message)
    {
        Intent notifyIntent = new Intent(this, MainActivity.class);
        notifyIntent.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent pendingIntent = PendingIntent.getActivities(this, 0,
                new Intent[] { notifyIntent }, PendingIntent.FLAG_UPDATE_CURRENT);
        Notification notification = new Notification.Builder(this)
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentTitle(title)
                .setContentText(message)
                .setAutoCancel(true)
                .setContentIntent(pendingIntent)
                .build();
        notification.defaults |= Notification.DEFAULT_SOUND;
        NotificationManager notificationManager =
                (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        notificationManager.notify(1, notification);
    }
}

