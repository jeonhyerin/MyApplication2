package com.example.bang.myapplication;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity_sunmi_budajjigae extends AppCompatActivity {

    TextView textView;
    TextView textView_1;
    int count=0;
    String result = "";
    String count_total ="";
    String togo_result ="";
    String count1_str="";
    String price_str="";
    int test=0;
    int price=0;
    Intent intent2;
    Intent intent;
    Intent intent3;
    TextView tv;

    private Button button_increse;
    private Button button_decrese;
    private Button button1;

    ArrayList store;
    int total_num=0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_sunmi_budajjigae);
        TextView tv = (TextView)findViewById(R.id.total_menu);
        final String store_name = tv.getText().toString();

        textView = (TextView) findViewById(R.id.count);
        textView_1 = (TextView) findViewById(R.id.name);

        Button button_back = (Button) findViewById(R.id.button13);

        button_increse = (Button) findViewById(R.id.increse);
        button_decrese = (Button) findViewById(R.id.decrese);

        button_increse.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                switch (v.getId()) {
                    case R.id.increse:
                        count++;
                        textView.setText("" + count);
                        break;
                    default:
                        break;
                }
            }
        });

        button_decrese.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                switch (v.getId()) {
                    case R.id.decrese:
                        if (count > 0) {
                            count--;
                            textView.setText("" + count);
                        }
                        break;
                    default:
                        break;
                }
            }
        });

        button1 = (Button) findViewById(R.id.button_next);
        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                total_num=1;
                price = 9000 * count;

                intent = new Intent(getApplicationContext(), MainActivity_shopping.class);

                count1_str = Integer.toString(count);
                result = textView_1.getText().toString() + "  ";
                if (count !=0) {
                    count_total += count1_str.toString()+"인분\n";
                }
                if (count1_str == "0") {
                    Toast.makeText(MainActivity_sunmi_budajjigae.this, "수량을 선택해 주세요", Toast.LENGTH_SHORT).show();
                }

                if (count1_str != "0") {
                    test=1;
                    intent = new Intent(getApplicationContext(), MainActivity_shopping.class);
                    intent.putExtra("test",test);
                    intent.putExtra("total_num",total_num);
                    price_str = String.valueOf(price);
                    intent.putExtra("sunmi_store",store_name);
                    intent.putExtra("sunmi_buda_name",result);
                    intent.putExtra("sunmi_buda_count",count_total);
                    intent.putExtra("sunmi_buda_price",price);
                    intent.putExtra("bool",true);
                    Toast.makeText(getApplicationContext(), "장바구니에 담겼습니다.", Toast.LENGTH_LONG).show();
                    startActivity(intent);
                }

            }
        });


        Button button_shop = (Button)findViewById(R.id.botton_shop);
        button_shop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), MainActivity_shopping.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
                startActivity(intent);
            }
        });
    }
}
