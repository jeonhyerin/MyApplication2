package com.example.bang.myapplication;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.webkit.CookieSyncManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Toast;


import java.io.BufferedReader;
import java.io.EOFException;
import java.io.InputStreamReader;
import java.net.CookieManager;
import java.net.URL;

public class activity_join extends AppCompatActivity{

    EditText editTxt_ID;
    EditText editTxt_PW;
    EditText editTxt_NM;

    RadioButton k_button, e_button, c_button;
    Button btn_Register;


    @Override

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_join);

        editTxt_ID = (EditText) findViewById(R.id.idInput);
        editTxt_PW = (EditText) findViewById(R.id.passwordInput);
        editTxt_NM = (EditText) findViewById(R.id.nameInput);

        k_button = (RadioButton) findViewById(R.id.rg_btn1);
        e_button = (RadioButton) findViewById(R.id.rg_btn2);
        c_button = (RadioButton) findViewById(R.id.rg_btn3);

        k_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Checked(v);
            }
        });
        e_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Checked(v);
            }
        });
        c_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Checked(v);
            }
        });
        btn_Register = (Button) findViewById(R.id.signUpButton);
        btn_Register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String joinid = editTxt_ID.getText().toString();
                String joinpwd = editTxt_PW.getText().toString();
                String joinname = editTxt_NM.getText().toString();
                String btn_checked = Checked(v);

                if (v == btn_Register) {
                    if (joinid.equals("") || joinpwd.equals("") || joinname.equals("")) {
                        Toast.makeText(activity_join.this, "빈칸없이 입력해주세요.", Toast.LENGTH_SHORT).show();
                    } else {
                        try {
                            String result = new RegisterUser().execute(joinid, joinpwd, joinname, btn_checked).get();
                            if (result.equals("id")) {
                                Toast.makeText(activity_join.this, "이미 존재하는 아이디입니다", Toast.LENGTH_SHORT).show();
                                editTxt_ID.setText("");
                                editTxt_PW.setText("");
                                editTxt_NM.setText("");
                            }
                        } catch (Exception e) {
                        }
                    }
                }
                Toast.makeText(activity_join.this, "축하합니다." +joinid+"님 회원가입 되었습니다", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(activity_join.this, Main2Activity_menu.class);
                startActivity(intent);

            }
        });
    }

    public String Checked(View v) {
        String resultText = "";
        if(k_button.isChecked()) {
            resultText = "한국어";
        }
        if(e_button.isChecked()) {
            resultText = "English";
        }
        if(c_button.isChecked()) {
            resultText = "중국어";
        }
        return resultText;
    }

    class RegisterUser extends AsyncTask<String, String, String>
    {
        ProgressDialog loading;
        URL register_url;

        protected void onPreExecute() {
            super.onPreExecute();
            loading = ProgressDialog.show(activity_join.this, "Please Wait", null, true, true);
        }

        @Override
        protected String doInBackground(String... params) {
            try {
                String URL = "http://192.168.43.192:8080/web-study-02/register.jsp";

                String _id = (String) params[0];
                String _pw = (String) params[1];
                String _nm = (String) params[2];
                String _lg = (String) params[3];

                String url_address = URL + "?id=" + _id + "&pw=" + _pw + "&name=" + _nm + "&language=" +_lg;

                register_url = new URL(url_address);
                BufferedReader in = new BufferedReader(new InputStreamReader(register_url.openStream()));

                String result = "";
                String temp = "";

                while ((temp = in.readLine()) != null) {
                    result += temp;
                }

                in.close();

                return result;
            } catch (Exception e) {
                return new String("Exception : " + e.getMessage());
            }
        }


        protected void onPostExecute(String result) {
            super.onPostExecute(result);
            loading.dismiss();
        }
    }
}


