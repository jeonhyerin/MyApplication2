package com.example.bang.myapplication;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class ListAdapter2 extends BaseAdapter{
    LayoutInflater inflater = null;
    private ArrayList<item> m_oData = null;
    private int nListCnt = 0;

    public ListAdapter2(ArrayList<item> _oData)  //data 셋
    {
        m_oData = _oData;
        nListCnt = m_oData.size();
    }

    @Override
    public int getCount()  //화면이 갱신되기전 호출, item이 몇개 생성될지 결정
    {
        Log.i("TAG", "getCount");
        return nListCnt;
    }

    @Override
    public Object getItem(int position)
    {
        return null;
    }

    @Override
    public long getItemId(int position)
    {
        return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent)  //return할 때 item Layout 넘겨주면 화면에 표시함
    {
        if (convertView == null)
        {
            final Context context = parent.getContext();
            if (inflater == null)
            {
                inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            }
            convertView = inflater.inflate(R.layout.item2, parent, false);
        }

        TextView oTextTitle = (TextView) convertView.findViewById(R.id.textTitle);
        TextView oTextDate = (TextView) convertView.findViewById(R.id.textDate);
        oTextTitle.setText(m_oData.get(position).strTitle);
        // position으로 현재 몇번째 item이 표시해야되는지 알려줌
        oTextDate.setText(m_oData.get(position).strDate);
        convertView.setTag(""+position);
        return convertView;
    }
}
