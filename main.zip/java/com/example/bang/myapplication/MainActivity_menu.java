package com.example.bang.myapplication;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;
import java.util.UUID;

public class MainActivity_menu extends AppCompatActivity{
    TextView beacon;
    TextView tv;
    private boolean isConnected;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_menu);
        Intent intent2 = getIntent();

        int num = intent2.getIntExtra("test",0);

        final Intent intent = getIntent();
        final int login_num = intent.getIntExtra("login_num",0);

        final Context context = this;
        final SessionManager session = new SessionManager(getApplicationContext());

        final Button button_login = (Button)findViewById(R.id.button_login);
        //Button button_logout = (Button)findViewById(R.id.button_logout);
        button_login.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                if (button_login.getText()=="로 그 아 웃"){
                    switch (v.getId()) {
                        case R.id.button_login:
                            AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(
                                    context);

                            // 제목셋팅
                            alertDialogBuilder.setTitle("알림");

                            // AlertDialog 셋팅
                            alertDialogBuilder
                                    .setMessage("로그아웃 하시겠습니까?")
                                    .setCancelable(false)
                                    .setPositiveButton("예",
                                            new DialogInterface.OnClickListener() {
                                                public void onClick(
                                                        DialogInterface dialog, int id) {
                                                    session.logoutUser();
                                                    Toast.makeText(getApplicationContext(), "로그아웃 되었습니다.", Toast.LENGTH_LONG).show();
                                                    button_login.setText("로 그 인");
                                                }
                                            })
                                    .setNegativeButton("아니오",
                                            new DialogInterface.OnClickListener() {
                                                public void onClick(
                                                        DialogInterface dialog, int id) {

                                                }
                                            });

                            // 다이얼로그 생성
                            AlertDialog alertDialog = alertDialogBuilder.create();

                            // 다이얼로그 보여주기
                            alertDialog.show();
                            break;

                        default:
                            break;
                    }
                }
                else {
                    Intent intent_login = new Intent(getApplicationContext(), LoginActivity.class);
                    startActivity(intent_login);
                }
            }
        });

        if (num == 1){
            button_login.setText("로 그 아 웃");
        }



        Button button_menu = (Button)findViewById(R.id.button_menu);

        button_menu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(),Main2Activity_menu.class);
                startActivity(intent);
            }
        });

        Button button_map = (Button)findViewById(R.id.button_close);
        button_map.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent intent2 = new Intent(getApplicationContext(),MainActivity_close_store.class);
                startActivity(intent2);
            }
        });

        Button button_intro = (Button)findViewById(R.id.button_intro);
        button_intro.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent intent3 = new Intent(getApplicationContext(),MainActivity_introduce.class);
                startActivity(intent3);
            }
        });

        Button button_mypage = (Button)findViewById(R.id.button_mypage);
        button_mypage.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent intent4 = new Intent(getApplicationContext(),MainActivity_mypage.class);
                startActivity(intent4);
            }
        });

    }



    @Override
    protected void onPause(){
        super.onPause();
    }
}
