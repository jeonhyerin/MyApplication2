package com.example.bang.myapplication;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.params.HttpParams;

import java.util.ArrayList;
import java.util.HashMap;

public class MainActivity_customer_delete extends AppCompatActivity {
    String btnValue;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_customer_delete);

        SessionManager session = new SessionManager(getApplicationContext());
        HashMap<String, String> user = session.getUserDetails();

        final String id = user.get(SessionManager.KEY_ID);

        final String URL = "http://192.168.43.192:8080/web-study-02/customer_delete.jsp";


        final Intent intent = getIntent();


        final Button deleteButton = (Button) findViewById(R.id.signUpButton);
        deleteButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                HttpClient client = new DefaultHttpClient();
                HttpPost post = new HttpPost(URL);

                if(v == deleteButton) {
                    try {
                        ArrayList<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>();
                        nameValuePairs.add(new BasicNameValuePair("id", id));
                        post.setEntity(new UrlEncodedFormEntity(nameValuePairs, "UTF-8"));

                        HttpParams params = client.getParams();

                        HttpResponse response = client.execute(post);
                    } catch (Exception e) {
                        e.printStackTrace();
                        client.getConnectionManager().shutdown();
                    }

                }
                Toast.makeText(MainActivity_customer_delete.this, "탈퇴 처리되었습니다", Toast.LENGTH_LONG).show();
                Intent intent = new Intent(getApplicationContext(), LoginActivity.class);
                startActivity(intent);
            }
        });
    }
}

