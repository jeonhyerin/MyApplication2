package com.example.bang.myapplication;

public class Value_object {
    private String main;
    private int sub;
    public Value_object(String main, int sub) {
        this.main = main; this.sub = sub;
    }
    public String getmain() {
        return main;
    }
    public int getsub() {
        return sub;
    }
    public void setmain(String main) {
        this.main = main;
    }
    public void setsub(int sub) {
        this.sub = sub;
    }

}


