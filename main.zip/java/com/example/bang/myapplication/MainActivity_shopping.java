package com.example.bang.myapplication;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.StrictMode;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.SparseBooleanArray;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.CheckBox;
import android.widget.Toast;

import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.params.HttpParams;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class MainActivity_shopping extends AppCompatActivity {
    Intent intent2;
    public static ListView listview1;
    public static ArrayAdapter<String> adapter;
    public static List<String> list1 = new ArrayList<>();
    public static ArrayList<item> oData = new ArrayList<>();
    public static item oItem;
    public static ListAdapter2 oAdapter;
    public static Button delete_button;
    public static Button deleteall_button;
    int num = 0;
    SharedPreferences food;
    SharedPreferences s_food;
    SharedPreferences pork;
    SharedPreferences bulgogi;
    SharedPreferences cabbage;
    SharedPreferences lettuce;
    public static List<Integer> price_list = new ArrayList<>();
    int t1 = 0;
    int t = 0;
    public static int total_price;
    public static boolean bool = false;
    public static SparseBooleanArray check;

    int price;
    int s_price;
    int f_price;
    int fishcake_price;
    int garlic_price;
    int garlic_shrimp_price;
    int garlic_rabboki_price;
    int garlic_jjolmyun_price;
    int lilane_price;
    int lilane_sundae_price;
    int lilane_ramyun_price;
    int lilane_gimbap_price;
    int heosuabi_price;
    int heosuabi_kimchi_price;
    int heosuabi_cow_price;
    int heosuabi_bone_price;
    int taepyung_price;
    int taepyung_soup_price;
    int taepyung_ulceun_price;
    int sunmi_price;
    int sunmi_kimchi_price;
    int sunmi_yuk_price;
    int sunmi_buda_price;
    int chicken_coke_price;
    int chicken_price;
    int chicken_spicy_price;
    int chicken_potato_price;
    int coffee_price;
    int coffee_latte_price;
    int coffee_moca_price;
    int coffee_capu_price;
    int hanyang_price;
    int hanyang_beef_price;
    int hanyang_bul_price;
    int hanyang_chicken_price;
    int singsing_cabbage_price;
    int singsing_cucumber_price;
    int singsing_lettuce_price;
    int singsing_raddish_price;


    String btn_checked;
    int index;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_shopping);

        if (Build.VERSION.SDK_INT > 9) {
            StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
            StrictMode.setThreadPolicy(policy);

        }

        SessionManager session = new SessionManager(getApplicationContext());
        HashMap<String, String> user = session.getUserDetails();

        final ArrayList<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>();
        final String id = user.get(SessionManager.KEY_ID);

        Intent intent = getIntent();
        final TextView textView_price = (TextView) findViewById(R.id.price);
        int total_num = intent.getIntExtra("total_num", 0);
        bool = intent.getBooleanExtra("bool", false);

        String store_name = intent.getStringExtra("store"); //가게이름
        String name = intent.getStringExtra("name"); // 음식이름
        String count = intent.getStringExtra("count"); //수량
        String check = intent.getStringExtra("check"); //특이사항
        price = intent.getIntExtra("price", 0); //가격

        String s_name = intent.getStringExtra("s_name");
        String s_count = intent.getStringExtra("s_count");
        String s_check = intent.getStringExtra("s_check");
        s_price = intent.getIntExtra("s_price", 0);

        String f_name = intent.getStringExtra("f_name");
        String f_count = intent.getStringExtra("f_count");
        f_price = intent.getIntExtra("f_price",0);

        String fishcake_name = intent.getStringExtra("fishcake_name");
        String fishcake_count = intent.getStringExtra("fishcake_count");
        fishcake_price = intent.getIntExtra("fishcake_price",0);

        String garlic_store_name = intent.getStringExtra("garlic_store");
        String garlic_name = intent.getStringExtra("garlic_name");
        String garlic_count = intent.getStringExtra("garlic_count");
        String garlic_check = intent.getStringExtra("garlic_check");
        garlic_price = intent.getIntExtra("garlic_price", 0);

        String garlic_shrimp_name = intent.getStringExtra("garlic_shrimp_name");String garlic_shrimp_count = intent.getStringExtra("garlic_shrimp_count");
        garlic_shrimp_price = intent.getIntExtra("garlic_shrimp_price",0);

        String garlic_rabboki_name = intent.getStringExtra("garlic_rabboki_name");
        String garlic_rabboki_count = intent.getStringExtra("garlic_rabboki_count");
        String garlic_rabboki_check = intent.getStringExtra("garlic_rabboki_check");
        garlic_rabboki_price = intent.getIntExtra("garlic_rabboki_price",0);

        String garlic_jjolmyun_name = intent.getStringExtra("garlic_jjolmyun_name");String garlic_jjolmyun_count = intent.getStringExtra("garlic_jjolmyun_count");
        garlic_jjolmyun_price = intent.getIntExtra("garlic_jjolmyun_price",0);

        String lilane_store_name = intent.getStringExtra("lilane_store");String lilane_name = intent.getStringExtra("lilane_name");
        String lilane_count = intent.getStringExtra("lilane_count");
        lilane_price = intent.getIntExtra("lilane_price", 0);

        String lilane_sundae_name = intent.getStringExtra("lilane_sundae_name");
        String lilane_sundae_count = intent.getStringExtra("lilane_sundae_count");
        String lilane_sundae_check = intent.getStringExtra("lilane_sundae_check");
        lilane_sundae_price = intent.getIntExtra("lilane_sundae_price", 0);

        String lilane_ramyun_name = intent.getStringExtra("lilane_ramyun_name");
        String lilane_ramyun_count = intent.getStringExtra("lilane_ramyun_count");
        lilane_ramyun_price = intent.getIntExtra("lilane_ramyun_price", 0);

        String lilane_gimbap_name = intent.getStringExtra("lilane_gimbap_name");
        String lilane_gimbap_count = intent.getStringExtra("lilane_gimbap_count");
        lilane_gimbap_price = intent.getIntExtra("lilane_gimbap_price", 0);

        String heosuabi_store_name = intent.getStringExtra("heosuabi_store");
        String heosuabi_name = intent.getStringExtra("heosuabi_name");
        String heosuabi_count = intent.getStringExtra("heosuabi_count");
        heosuabi_price = intent.getIntExtra("heosuabi_price", 0);

        String heosuabi_kimchi_name = intent.getStringExtra("heosuabi_kimchi_name");
        String heosuabi_kimchi_count = intent.getStringExtra("heosuabi_kimchi_count");
        heosuabi_kimchi_price = intent.getIntExtra("heosuabi_kimchi_price", 0);

        String heosuabi_cow_name = intent.getStringExtra("heosuabi_cow_name");
        String heosuabi_cow_count = intent.getStringExtra("heosuabi_cow_count");
        heosuabi_cow_price = intent.getIntExtra("heosuabi_cow_price", 0);

        String heosuabi_bone_name = intent.getStringExtra("heosuabi_bone_name");
        String heosuabi_bone_count = intent.getStringExtra("heosuabi_bone_count");
        heosuabi_bone_price = intent.getIntExtra("heosuabi_bone_price", 0);

        String taepyung_store_name = intent.getStringExtra("taepyung_store");
        String taepyung_name = intent.getStringExtra("taepyung_name");
        String taepyung_count = intent.getStringExtra("taepyung_count");
        taepyung_price = intent.getIntExtra("taepyung_price", 0);

        String taepyung_soup_name = intent.getStringExtra("taepyung_soup_name");
        String taepyung_soup_count = intent.getStringExtra("taepyung_soup_count");
        taepyung_soup_price = intent.getIntExtra("taepyung_soup_price", 0);

        String taepyung_ulceun_name = intent.getStringExtra("taepyung_ulceun_name");
        String taepyung_ulceun_count = intent.getStringExtra("taepyung_ulceun_count");
        taepyung_ulceun_price = intent.getIntExtra("taepyung_ulceun_price", 0);

        String sunmi_store_name = intent.getStringExtra("sunmi_store");
        String sunmi_name = intent.getStringExtra("sunmi_dan_name");
        String sunmi_count = intent.getStringExtra("sunmi_dan_count");
        sunmi_price = intent.getIntExtra("sunmi_dan_price", 0);

        String sunmi_kimchi_name = intent.getStringExtra("sunmi_kimchi_name");
        String sunmi_kimchi_count = intent.getStringExtra("sunmi_kimchi_count");
        sunmi_kimchi_price = intent.getIntExtra("sunmi_kimchi_price", 0);

        String sunmi_yuk_name = intent.getStringExtra("sunmi_yuk_name");
        String sunmi_yuk_count = intent.getStringExtra("sunmi_yuk_count");
        sunmi_yuk_price = intent.getIntExtra("sunmi_yuk_price", 0);

        String sunmi_buda_name = intent.getStringExtra("sunmi_buda_name");
        String sunmi_buda_count = intent.getStringExtra("sunmi_buda_count");
        sunmi_buda_price = intent.getIntExtra("sunmi_buda_price", 0);

        String chicken_store_name = intent.getStringExtra("chicken_store");
        String chicken_coke_name = intent.getStringExtra("chicken_coke_name");
        String chicken_coke_count = intent.getStringExtra("chicken_coke_count");
        chicken_coke_price = intent.getIntExtra("chicken_coke_price", 0);

        String chicken_name = intent.getStringExtra("chicken_name");
        String chicken_count = intent.getStringExtra("chicken_count");
        chicken_price = intent.getIntExtra("chicken_price", 0);

        String chicken_spicy_name = intent.getStringExtra("chicken_spicy_name");
        String chicken_spicy_count = intent.getStringExtra("chicken_spicy_count");
        chicken_spicy_price = intent.getIntExtra("chicken_spicy_price", 0);

        String chicken_potato_name = intent.getStringExtra("chicken_potato_name");
        String chicken_potato_count = intent.getStringExtra("chicken_potato_count");
        chicken_potato_price = intent.getIntExtra("chicken_potato_price", 0);

        String coffee_store_name = intent.getStringExtra("coffee_store");
        String coffee_name = intent.getStringExtra("coffee_name");
        String coffee_count = intent.getStringExtra("coffee_count");
        String coffee_ice = intent.getStringExtra("coffee_ice");
        coffee_price = intent.getIntExtra("coffee_price", 0);

        String coffee_latte_name = intent.getStringExtra("coffee_latte_name");
        String coffee_latte_count = intent.getStringExtra("coffee_latte_count");
        String coffee_latte_ice = intent.getStringExtra("coffee_latte_ice");
        coffee_latte_price = intent.getIntExtra("coffee_latte_price", 0);

        String coffee_moca_name = intent.getStringExtra("coffee_moca_name");
        String coffee_moca_count = intent.getStringExtra("coffee_moca_count");
        String coffee_moca_ice = intent.getStringExtra("coffee_moca_ice");
        coffee_moca_price = intent.getIntExtra("coffee_moca_price", 0);

        String coffee_capu_name = intent.getStringExtra("coffee_capu_name");
        String coffee_capu_count = intent.getStringExtra("coffee_capu_count");
        String coffee_capu_ice = intent.getStringExtra("coffee_capu_ice");
        coffee_capu_price = intent.getIntExtra("coffee_capu_price", 0);

        String hanyang_store_name = intent.getStringExtra("hanyang_store");
        String hanyang_name = intent.getStringExtra("hanyang_name");
        String hanyang_count = intent.getStringExtra("hanyang_count");
        hanyang_price = intent.getIntExtra("hanyang_price", 0);

        String hanyang_beef_name = intent.getStringExtra("hanyang_beef_name");
        String hanyang_beef_count = intent.getStringExtra("hanyang_beef_count");
        hanyang_beef_price = intent.getIntExtra("hanyang_beef_price", 0);

        String hanyang_bul_name = intent.getStringExtra("hanyang_bul_name");
        String hanyang_bul_count = intent.getStringExtra("hanyang_bul_count");
        hanyang_bul_price = intent.getIntExtra("hanyang_bul_price", 0);

        String hanyang_chicken_name = intent.getStringExtra("hanyang_chicken_name");
        String hanyang_chicken_count = intent.getStringExtra("hanyang_chicken_count");
        hanyang_chicken_price = intent.getIntExtra("hanyang_chicken_price", 0);

        String singsing_store_name = intent.getStringExtra("singsing_store");
        String singsing_cabbage_name = intent.getStringExtra("singsing_cabbage_name");
        String singsing_cabbage_count = intent.getStringExtra("singsing_cabbage_count");
        singsing_cabbage_price = intent.getIntExtra("singsing_cabbage_price", 0);

        String singsing_lettuce_name = intent.getStringExtra("singsing_lettuce_name");
        String singsing_lettuce_count = intent.getStringExtra("singsing_lettuce_count");
        singsing_lettuce_price = intent.getIntExtra("singsing_lettuce_price", 0);

        String singsing_raddish_name = intent.getStringExtra("singsing_raddish_name");
        String singsing_raddish_count = intent.getStringExtra("singsing_raddish_count");
        singsing_raddish_price = intent.getIntExtra("singsing_raddish_price", 0);

        String singsing_cucumber_name = intent.getStringExtra("singsing_cucumber_name");
        String singsing_cucumber_count = intent.getStringExtra("singsing_cucumber_count");
        singsing_cucumber_price = intent.getIntExtra("singsing_cucumber_price", 0);


        final CheckBox checkBox = (CheckBox) findViewById(R.id.checkBox2); // 전체포장


        checkBox.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Checked(v);
                btn_checked = Checked(v);
            }
        });

        listview1 = (ListView) findViewById(R.id.listview1);
        oAdapter = new ListAdapter2(oData);
        listview1.setAdapter(oAdapter);
        oItem = new item();

        if (bool == true) {
            if (name != null && total_num == 1) { // 언니네 떡볶이 담기
                final String URL = "http://192.168.43.192:8080/web-study-02/list1_food1_unnine.jsp";
                oItem.strTitle = store_name;
                oItem.strDate = name + count + check;
                price_list.add(price);
                oData.add(oItem);

                String price1 = Integer.toString(price);


                HttpClient client = new DefaultHttpClient();
                HttpPost post = new HttpPost(URL);

                try {
                    nameValuePairs.add(new BasicNameValuePair("store_name", store_name));
                    nameValuePairs.add(new BasicNameValuePair("toppoki", name));
                    nameValuePairs.add(new BasicNameValuePair("price", price1));
                    nameValuePairs.add(new BasicNameValuePair("togo", btn_checked));
                    nameValuePairs.add(new BasicNameValuePair("count", count));
                    nameValuePairs.add(new BasicNameValuePair("check", check));
                    nameValuePairs.add(new BasicNameValuePair("id", id));
                    post.setEntity(new UrlEncodedFormEntity(nameValuePairs, "UTF-8"));

                    HttpParams params = client.getParams();

                    HttpResponse response = client.execute(post);
                } catch (Exception e) {
                    e.printStackTrace();
                    client.getConnectionManager().shutdown();
                }
            }

            if (s_name != null && total_num == 1) { // 언니네 순대 담기
                oItem.strTitle = store_name;
                oItem.strDate = s_name + s_count + s_check;
                price_list.add(s_price);
                oData.add(oItem);

                String s_price1 = Integer.toString(s_price);
                final String URL = "http://192.168.43.192:8080/web-study-02/list1_food1_unnine.jsp";

                HttpClient client = new DefaultHttpClient();
                HttpPost post = new HttpPost(URL);

                try {
                    nameValuePairs.add(new BasicNameValuePair("store_name", store_name));
                    nameValuePairs.add(new BasicNameValuePair("sundae", s_name));
                    nameValuePairs.add(new BasicNameValuePair("s_price", s_price1));
                    nameValuePairs.add(new BasicNameValuePair("s_count", s_count));
                    nameValuePairs.add(new BasicNameValuePair("s_check", s_check));
                    nameValuePairs.add(new BasicNameValuePair("id", id));
                    post.setEntity(new UrlEncodedFormEntity(nameValuePairs, "UTF-8"));

                    HttpParams params = client.getParams();

                    HttpResponse response = client.execute(post);
                } catch (Exception e) {
                    e.printStackTrace();
                    client.getConnectionManager().shutdown();
                }
            }

            if (f_name != null && total_num == 1) { // 튀김 담기
                oItem.strTitle = store_name;
                oItem.strDate = f_name + f_count;
                price_list.add(f_price);
                oData.add(oItem);


                String f_price1 = Integer.toString(f_price);
                final String URL = "http://192.168.43.192:8080/web-study-02/list1_food1_unnine.jsp";

                HttpClient client = new DefaultHttpClient();
                HttpPost post = new HttpPost(URL);

                try {
                    nameValuePairs.add(new BasicNameValuePair("store_name", store_name));
                    nameValuePairs.add(new BasicNameValuePair("friedfood", f_name));
                    nameValuePairs.add(new BasicNameValuePair("f_price", f_price1));
                    nameValuePairs.add(new BasicNameValuePair("f_count", f_count));
                    nameValuePairs.add(new BasicNameValuePair("id", id));
                    post.setEntity(new UrlEncodedFormEntity(nameValuePairs, "UTF-8"));

                    HttpParams params = client.getParams();

                    HttpResponse response = client.execute(post);
                } catch (Exception e) {
                    e.printStackTrace();
                    client.getConnectionManager().shutdown();
                }
            }
            if (fishcake_name != null && total_num == 1) { // 오뎅 담기
                oItem.strTitle = store_name;
                oItem.strDate = fishcake_name + fishcake_count;
                price_list.add(fishcake_price);
                oData.add(oItem);


                String fishcake_price1 = Integer.toString(fishcake_price);
                final String URL = "http://192.168.43.192:8080/web-study-02/list1_food1_unnine.jsp";

                HttpClient client = new DefaultHttpClient();
                HttpPost post = new HttpPost(URL);

                try {
                    nameValuePairs.add(new BasicNameValuePair("store_name", store_name));
                    nameValuePairs.add(new BasicNameValuePair("ricefish", fishcake_name));
                    nameValuePairs.add(new BasicNameValuePair("fishcake_price", fishcake_price1));
                    nameValuePairs.add(new BasicNameValuePair("fishcake_count", fishcake_count));
                    nameValuePairs.add(new BasicNameValuePair("id", id));
                    post.setEntity(new UrlEncodedFormEntity(nameValuePairs, "UTF-8"));

                    HttpParams params = client.getParams();

                    HttpResponse response = client.execute(post);
                } catch (Exception e) {
                    e.printStackTrace();
                    client.getConnectionManager().shutdown();
                }
            }
            if (garlic_name != null && total_num ==1){
                oItem.strTitle = garlic_store_name;
                oItem.strDate = garlic_name + garlic_count + garlic_check;
                price_list.add(garlic_price);
                oData.add(oItem);


                String garlic_price1 = Integer.toString(garlic_price);
                final String URL1 = "http://192.168.43.192:8080/web-study-02/list1_food1_garlictoppoki.jsp";

                HttpClient client = new DefaultHttpClient();
                HttpPost post = new HttpPost(URL1);

                try {
                    nameValuePairs.add(new BasicNameValuePair("store_name2", garlic_store_name));
                    nameValuePairs.add(new BasicNameValuePair("garlic_toppoki", garlic_name));
                    nameValuePairs.add(new BasicNameValuePair("garlic_price", garlic_price1));
                    nameValuePairs.add(new BasicNameValuePair("garlic_count", garlic_count));
                    nameValuePairs.add(new BasicNameValuePair("garlic_check", garlic_check));
                    nameValuePairs.add(new BasicNameValuePair("id", id));
                    post.setEntity(new UrlEncodedFormEntity(nameValuePairs, "UTF-8"));

                    HttpParams params = client.getParams();

                    HttpResponse response = client.execute(post);
                } catch (Exception e) {
                    e.printStackTrace();
                    client.getConnectionManager().shutdown();
                }
            }
            if (garlic_shrimp_name != null && total_num==1){
                oItem.strTitle = garlic_store_name;
                oItem.strDate = garlic_shrimp_name + garlic_shrimp_count;
                price_list.add(garlic_shrimp_price);
                oData.add(oItem);


                String garlic_shrimp_price1 = Integer.toString(garlic_shrimp_price);
                final String URL1 = "http://192.168.43.192:8080/web-study-02/list1_food1_garlictoppoki.jsp";

                HttpClient client = new DefaultHttpClient();
                HttpPost post = new HttpPost(URL1);

                try {
                    nameValuePairs.add(new BasicNameValuePair("store_name2", garlic_store_name));
                    nameValuePairs.add(new BasicNameValuePair("garlic_shrimp", garlic_shrimp_name));
                    nameValuePairs.add(new BasicNameValuePair("garlic_shrimp_price", garlic_shrimp_price1));
                    nameValuePairs.add(new BasicNameValuePair("garlic_shrimp_count", garlic_shrimp_count));
                    nameValuePairs.add(new BasicNameValuePair("id", id));
                    post.setEntity(new UrlEncodedFormEntity(nameValuePairs, "UTF-8"));

                    HttpParams params = client.getParams();

                    HttpResponse response = client.execute(post);
                } catch (Exception e) {
                    e.printStackTrace();
                    client.getConnectionManager().shutdown();
                }
            }
            if (garlic_rabboki_name != null && total_num==1){
                oItem.strTitle = garlic_store_name;
                oItem.strDate = garlic_rabboki_name + garlic_rabboki_count + garlic_rabboki_check;
                price_list.add(garlic_rabboki_price);
                oData.add(oItem);


                String garlic_rabboki_price1 = Integer.toString(garlic_rabboki_price);
                final String URL1 = "http://192.168.43.192:8080/web-study-02/list1_food1_garlictoppoki.jsp";

                HttpClient client = new DefaultHttpClient();
                HttpPost post = new HttpPost(URL1);

                try {
                    nameValuePairs.add(new BasicNameValuePair("store_name2", garlic_store_name));
                    nameValuePairs.add(new BasicNameValuePair("garlic_rabboki", garlic_rabboki_name));
                    nameValuePairs.add(new BasicNameValuePair("garlic_rabboki_price", garlic_rabboki_price1));
                    nameValuePairs.add(new BasicNameValuePair("garlic_rabboki_count", garlic_rabboki_count));
                    nameValuePairs.add(new BasicNameValuePair("garlic_rabboki_check", garlic_rabboki_check));
                    nameValuePairs.add(new BasicNameValuePair("id", id));
                    post.setEntity(new UrlEncodedFormEntity(nameValuePairs, "UTF-8"));

                    HttpParams params = client.getParams();

                    HttpResponse response = client.execute(post);
                } catch (Exception e) {
                    e.printStackTrace();
                    client.getConnectionManager().shutdown();
                }
            }
            if (garlic_jjolmyun_name != null && total_num==1){
                oItem.strTitle = garlic_store_name;
                oItem.strDate = garlic_jjolmyun_name + garlic_jjolmyun_count;
                price_list.add(garlic_jjolmyun_price);
                oData.add(oItem);


                String garlic_jjolmyun_price1 = Integer.toString(garlic_jjolmyun_price);
                final String URL1 = "http://192.168.43.192:8080/web-study-02/list1_food1_garlictoppoki.jsp";

                HttpClient client = new DefaultHttpClient();
                HttpPost post = new HttpPost(URL1);

                try {
                    nameValuePairs.add(new BasicNameValuePair("store_name2", garlic_store_name));
                    nameValuePairs.add(new BasicNameValuePair("garlic_jjolmyun", garlic_jjolmyun_name));
                    nameValuePairs.add(new BasicNameValuePair("garlic_jjolmyun_price", garlic_jjolmyun_price1));
                    nameValuePairs.add(new BasicNameValuePair("garlic_jjolmyun_count", garlic_jjolmyun_count));
                    nameValuePairs.add(new BasicNameValuePair("id", id));
                    post.setEntity(new UrlEncodedFormEntity(nameValuePairs, "UTF-8"));

                    HttpParams params = client.getParams();

                    HttpResponse response = client.execute(post);
                } catch (Exception e) {
                    e.printStackTrace();
                    client.getConnectionManager().shutdown();
                }
            }
            if (lilane_name != null && total_num==1){
                oItem.strTitle = lilane_store_name;
                oItem.strDate = lilane_name + lilane_count;
                price_list.add(lilane_price);
                oData.add(oItem);


                String lilane_price1 = Integer.toString(lilane_price);
                final String URL2 = "http://192.168.43.192:8080/web-study-02/list1_food1_lilane.jsp";

                HttpClient client = new DefaultHttpClient();
                HttpPost post = new HttpPost(URL2);


                try {
                    nameValuePairs.add(new BasicNameValuePair("store_name3", lilane_store_name));
                    nameValuePairs.add(new BasicNameValuePair("toppoki", lilane_name));
                    nameValuePairs.add(new BasicNameValuePair("price", lilane_price1));
                    nameValuePairs.add(new BasicNameValuePair("count", lilane_count));
                    nameValuePairs.add(new BasicNameValuePair("id", id));
                    post.setEntity(new UrlEncodedFormEntity(nameValuePairs, "UTF-8"));

                    HttpParams params = client.getParams();

                    HttpResponse response = client.execute(post);
                } catch (Exception e) {
                    e.printStackTrace();
                    client.getConnectionManager().shutdown();
                }
            }
            if (lilane_sundae_name != null && total_num==1){
                oItem.strTitle = lilane_store_name;
                oItem.strDate = lilane_sundae_name + lilane_sundae_count + lilane_sundae_check;
                price_list.add(lilane_sundae_price);
                oData.add(oItem);


                final String URL2 = "http://192.168.43.192:8080/web-study-02/list1_food1_lilane.jsp";
                String lilane_sundae_price1 = Integer.toString(lilane_sundae_price);

                HttpClient client = new DefaultHttpClient();
                HttpPost post = new HttpPost(URL2);


                try {
                    nameValuePairs.add(new BasicNameValuePair("store_name3", lilane_store_name));
                    nameValuePairs.add(new BasicNameValuePair("sundae", lilane_sundae_name));
                    nameValuePairs.add(new BasicNameValuePair("s_price", lilane_sundae_price1));
                    nameValuePairs.add(new BasicNameValuePair("s_count", lilane_sundae_count));
                    nameValuePairs.add(new BasicNameValuePair("s_check", lilane_sundae_check));
                    nameValuePairs.add(new BasicNameValuePair("id", id));
                    post.setEntity(new UrlEncodedFormEntity(nameValuePairs, "UTF-8"));

                    HttpParams params = client.getParams();

                    HttpResponse response = client.execute(post);
                } catch (Exception e) {
                    e.printStackTrace();
                    client.getConnectionManager().shutdown();
                }
            }
            if (lilane_ramyun_name != null && total_num==1){
                oItem.strTitle = lilane_store_name;
                oItem.strDate = lilane_ramyun_name + lilane_ramyun_count;
                price_list.add(lilane_ramyun_price);
                oData.add(oItem);


                final String URL2 = "http://192.168.43.192:8080/web-study-02/list1_food1_lilane.jsp";
                String lilane_ramyun_price1 = Integer.toString(lilane_ramyun_price);

                HttpClient client = new DefaultHttpClient();
                HttpPost post = new HttpPost(URL2);


                try {
                    nameValuePairs.add(new BasicNameValuePair("store_name3", lilane_store_name));
                    nameValuePairs.add(new BasicNameValuePair("ramyun", lilane_ramyun_name));
                    nameValuePairs.add(new BasicNameValuePair("r_price", lilane_ramyun_price1));
                    nameValuePairs.add(new BasicNameValuePair("r_count", lilane_ramyun_count));
                    nameValuePairs.add(new BasicNameValuePair("togo", btn_checked));
                    nameValuePairs.add(new BasicNameValuePair("id", id));
                    post.setEntity(new UrlEncodedFormEntity(nameValuePairs, "UTF-8"));

                    HttpParams params = client.getParams();

                    HttpResponse response = client.execute(post);
                } catch (Exception e) {
                    e.printStackTrace();
                    client.getConnectionManager().shutdown();
                }
            }
            if (lilane_gimbap_name != null && total_num==1){
                oItem.strTitle = lilane_store_name;
                oItem.strDate = lilane_gimbap_name + lilane_gimbap_count;
                price_list.add(lilane_gimbap_price);
                oData.add(oItem);


                final String URL2 = "http://192.168.43.192:8080/web-study-02/list1_food1_lilane.jsp";
                String lilane_gimbap_price1 = Integer.toString(lilane_gimbap_price);

                HttpClient client = new DefaultHttpClient();
                HttpPost post = new HttpPost(URL2);


                try {
                    nameValuePairs.add(new BasicNameValuePair("store_name3", lilane_store_name));
                    nameValuePairs.add(new BasicNameValuePair("gimbap", lilane_gimbap_name));
                    nameValuePairs.add(new BasicNameValuePair("g_price", lilane_gimbap_price1));
                    nameValuePairs.add(new BasicNameValuePair("g_count", lilane_gimbap_count));
                    nameValuePairs.add(new BasicNameValuePair("id", id));
                    post.setEntity(new UrlEncodedFormEntity(nameValuePairs, "UTF-8"));

                    HttpParams params = client.getParams();

                    HttpResponse response = client.execute(post);
                } catch (Exception e) {
                    e.printStackTrace();
                    client.getConnectionManager().shutdown();
                }
            }

            if (heosuabi_name != null && total_num==1){
                oItem.strTitle = heosuabi_store_name;
                oItem.strDate = heosuabi_name + heosuabi_count;
                price_list.add(heosuabi_price);
                oData.add(oItem);


                final String URL3 = "http://192.168.43.192:8080/web-study-02/list1_food2_heosuabi.jsp";
                String heosuabi_price1 = Integer.toString(heosuabi_price);

                HttpClient client = new DefaultHttpClient();
                HttpPost post = new HttpPost(URL3);


                try {
                    nameValuePairs.add(new BasicNameValuePair("store_name", heosuabi_store_name));
                    nameValuePairs.add(new BasicNameValuePair("sundae_soup", heosuabi_name)); // 허수아비 순댓국
                    nameValuePairs.add(new BasicNameValuePair("price", heosuabi_price1));
                    nameValuePairs.add(new BasicNameValuePair("count", heosuabi_count));
                    nameValuePairs.add(new BasicNameValuePair("id", id));
                    post.setEntity(new UrlEncodedFormEntity(nameValuePairs, "UTF-8"));

                    HttpParams params = client.getParams();

                    HttpResponse response = client.execute(post);
                } catch (Exception e) {
                    e.printStackTrace();
                    client.getConnectionManager().shutdown();
                }
            }
            if (heosuabi_kimchi_name != null && total_num==1){
                oItem.strTitle = heosuabi_store_name;
                oItem.strDate = heosuabi_kimchi_name + heosuabi_kimchi_count;
                price_list.add(heosuabi_kimchi_price);
                oData.add(oItem);


                final String URL3 = "http://192.168.43.192:8080/web-study-02/list1_food2_heosuabi.jsp";
                String heosuabi_kimchi_price1 = Integer.toString(heosuabi_kimchi_price);

                HttpClient client = new DefaultHttpClient();
                HttpPost post = new HttpPost(URL3);


                try {
                    nameValuePairs.add(new BasicNameValuePair("store_name", heosuabi_store_name));
                    nameValuePairs.add(new BasicNameValuePair("kimchi_sundae", heosuabi_kimchi_name)); // 허수아비 순댓국
                    nameValuePairs.add(new BasicNameValuePair("kimchi_price", heosuabi_kimchi_price1));
                    nameValuePairs.add(new BasicNameValuePair("kimchi_count", heosuabi_kimchi_count));
                    nameValuePairs.add(new BasicNameValuePair("id", id));
                    post.setEntity(new UrlEncodedFormEntity(nameValuePairs, "UTF-8"));

                    HttpParams params = client.getParams();

                    HttpResponse response = client.execute(post);
                } catch (Exception e) {
                    e.printStackTrace();
                    client.getConnectionManager().shutdown();
                }
            }
            if (heosuabi_cow_name != null && total_num==1){
                oItem.strTitle = heosuabi_store_name;
                oItem.strDate = heosuabi_cow_name + heosuabi_cow_count;
                price_list.add(heosuabi_cow_price);
                oData.add(oItem);


                final String URL3 = "http://192.168.43.192:8080/web-study-02/list1_food2_heosuabi.jsp";
                String heosuabi_cow_price1 = Integer.toString(heosuabi_cow_price);

                HttpClient client = new DefaultHttpClient();
                HttpPost post = new HttpPost(URL3);


                try {
                    nameValuePairs.add(new BasicNameValuePair("store_name", heosuabi_store_name));
                    nameValuePairs.add(new BasicNameValuePair("cow_soup", heosuabi_cow_name)); // 허수아비 순댓국
                    nameValuePairs.add(new BasicNameValuePair("cow_price", heosuabi_cow_price1));
                    nameValuePairs.add(new BasicNameValuePair("cow_count", heosuabi_cow_count));
                    nameValuePairs.add(new BasicNameValuePair("id", id));
                    post.setEntity(new UrlEncodedFormEntity(nameValuePairs, "UTF-8"));

                    HttpParams params = client.getParams();

                    HttpResponse response = client.execute(post);
                } catch (Exception e) {
                    e.printStackTrace();
                    client.getConnectionManager().shutdown();
                }
            }
            if (heosuabi_bone_name != null && total_num==1){
                oItem.strTitle = heosuabi_store_name;
                oItem.strDate = heosuabi_bone_name + heosuabi_bone_count;
                price_list.add(heosuabi_bone_price);
                oData.add(oItem);


                final String URL3 = "http://192.168.43.192:8080/web-study-02/list1_food2_heosuabi.jsp";
                String heosuabi_bone_price1 = Integer.toString(heosuabi_bone_price);

                HttpClient client = new DefaultHttpClient();
                HttpPost post = new HttpPost(URL3);


                try {
                    nameValuePairs.add(new BasicNameValuePair("store_name", heosuabi_store_name));
                    nameValuePairs.add(new BasicNameValuePair("bone_soup", heosuabi_bone_name)); // 허수아비 순댓국
                    nameValuePairs.add(new BasicNameValuePair("bone_price", heosuabi_bone_price1));
                    nameValuePairs.add(new BasicNameValuePair("bone_count", heosuabi_bone_count));
                    nameValuePairs.add(new BasicNameValuePair("id", id));
                    post.setEntity(new UrlEncodedFormEntity(nameValuePairs, "UTF-8"));

                    HttpParams params = client.getParams();

                    HttpResponse response = client.execute(post);
                } catch (Exception e) {
                    e.printStackTrace();
                    client.getConnectionManager().shutdown();
                }
            }
            if (taepyung_name != null && total_num==1){
                oItem.strTitle = taepyung_store_name;
                oItem.strDate = taepyung_name + taepyung_count;
                price_list.add(taepyung_price);
                oData.add(oItem);

                String taepyung_price1 = Integer.toString(taepyung_price);
                final String URL1 = "http://192.168.43.192:8080/web-study-02/list1_food2_taepyung.jsp";

                HttpClient client = new DefaultHttpClient();
                HttpPost post = new HttpPost(URL1);

                try {
                    nameValuePairs.add(new BasicNameValuePair("store_name2", taepyung_store_name));
                    nameValuePairs.add(new BasicNameValuePair("sundae", taepyung_name));
                    nameValuePairs.add(new BasicNameValuePair("price", taepyung_price1));
                    nameValuePairs.add(new BasicNameValuePair("count", taepyung_count));
                    nameValuePairs.add(new BasicNameValuePair("id", id));
                    post.setEntity(new UrlEncodedFormEntity(nameValuePairs, "UTF-8"));

                    HttpParams params = client.getParams();

                    HttpResponse response = client.execute(post);
                } catch (Exception e) {
                    e.printStackTrace();
                    client.getConnectionManager().shutdown();
                }
            }
            if (taepyung_soup_name != null && total_num==1){
                oItem.strTitle = taepyung_store_name;
                oItem.strDate = taepyung_soup_name + taepyung_soup_count;
                price_list.add(taepyung_soup_price);
                oData.add(oItem);


                String taepyung_soup_price1 = Integer.toString(taepyung_soup_price);
                final String URL1 = "http://192.168.43.192:8080/web-study-02/list1_food2_taepyung.jsp";

                HttpClient client = new DefaultHttpClient();
                HttpPost post = new HttpPost(URL1);

                try {
                    nameValuePairs.add(new BasicNameValuePair("store_name2", taepyung_store_name));
                    nameValuePairs.add(new BasicNameValuePair("sundae_soup", taepyung_soup_name));
                    nameValuePairs.add(new BasicNameValuePair("s_price", taepyung_soup_price1));
                    nameValuePairs.add(new BasicNameValuePair("s_count", taepyung_soup_count));
                    nameValuePairs.add(new BasicNameValuePair("id", id));
                    post.setEntity(new UrlEncodedFormEntity(nameValuePairs, "UTF-8"));

                    HttpParams params = client.getParams();

                    HttpResponse response = client.execute(post);
                } catch (Exception e) {
                    e.printStackTrace();
                    client.getConnectionManager().shutdown();
                }
            }
            if (taepyung_ulceun_name != null && total_num==1){
                oItem.strTitle = taepyung_store_name;
                oItem.strDate = taepyung_ulceun_name + taepyung_ulceun_count;
                price_list.add(taepyung_ulceun_price);
                oData.add(oItem);


                String taepyung_ulceun_price1 = Integer.toString(taepyung_ulceun_price);
                final String URL1 = "http://192.168.43.192:8080/web-study-02/list1_food2_taepyung.jsp";

                HttpClient client = new DefaultHttpClient();
                HttpPost post = new HttpPost(URL1);

                try {
                    nameValuePairs.add(new BasicNameValuePair("store_name2", taepyung_store_name));
                    nameValuePairs.add(new BasicNameValuePair("ulceun_soup", taepyung_ulceun_name));
                    nameValuePairs.add(new BasicNameValuePair("ulceun_price", taepyung_ulceun_price1));
                    nameValuePairs.add(new BasicNameValuePair("ulceun_count", taepyung_ulceun_count));
                    nameValuePairs.add(new BasicNameValuePair("id", id));
                    post.setEntity(new UrlEncodedFormEntity(nameValuePairs, "UTF-8"));

                    HttpParams params = client.getParams();

                    HttpResponse response = client.execute(post);
                } catch (Exception e) {
                    e.printStackTrace();
                    client.getConnectionManager().shutdown();
                }
            }
            if (sunmi_name != null && total_num==1){
                oItem.strTitle = sunmi_store_name;
                oItem.strDate = sunmi_name + sunmi_count;
                price_list.add(sunmi_price);
                oData.add(oItem);

                String sunmi_price1 = Integer.toString(sunmi_price);
                final String URL2 = "http://192.168.43.192:8080/web-study-02/list1_food2_sunmi.jsp";

                HttpClient client = new DefaultHttpClient();
                HttpPost post = new HttpPost(URL2);

                try {
                    nameValuePairs.add(new BasicNameValuePair("store_name3", sunmi_store_name));
                    nameValuePairs.add(new BasicNameValuePair("danjangjjigae", sunmi_name));
                    nameValuePairs.add(new BasicNameValuePair("price", sunmi_price1));
                    nameValuePairs.add(new BasicNameValuePair("count", sunmi_count));
                    nameValuePairs.add(new BasicNameValuePair("togo", btn_checked));
                    nameValuePairs.add(new BasicNameValuePair("id", id));
                    post.setEntity(new UrlEncodedFormEntity(nameValuePairs, "UTF-8"));

                    HttpParams params = client.getParams();

                    HttpResponse response = client.execute(post);
                } catch (Exception e) {
                    e.printStackTrace();
                    client.getConnectionManager().shutdown();
                }
            }
            if (sunmi_kimchi_name != null && total_num==1){
                oItem.strTitle = sunmi_store_name;
                oItem.strDate = sunmi_kimchi_name + sunmi_kimchi_count;
                price_list.add(sunmi_kimchi_price);
                oData.add(oItem);


                String sunmi_kimchi_price1 = Integer.toString(sunmi_kimchi_price);
                final String URL2 = "http://192.168.43.192:8080/web-study-02/list1_food2_sunmi.jsp";

                HttpClient client = new DefaultHttpClient();
                HttpPost post = new HttpPost(URL2);

                try {
                    nameValuePairs.add(new BasicNameValuePair("store_name3", sunmi_store_name));
                    nameValuePairs.add(new BasicNameValuePair("kimchi_soup", sunmi_kimchi_name));
                    nameValuePairs.add(new BasicNameValuePair("kimchi_price", sunmi_kimchi_price1));
                    nameValuePairs.add(new BasicNameValuePair("kimchi_count", sunmi_kimchi_count));
                    nameValuePairs.add(new BasicNameValuePair("id", id));
                    post.setEntity(new UrlEncodedFormEntity(nameValuePairs, "UTF-8"));

                    HttpParams params = client.getParams();

                    HttpResponse response = client.execute(post);
                } catch (Exception e) {
                    e.printStackTrace();
                    client.getConnectionManager().shutdown();
                }
            }
            if (sunmi_yuk_name != null && total_num==1){
                oItem.strTitle = sunmi_store_name;
                oItem.strDate = sunmi_yuk_name + sunmi_yuk_count;
                price_list.add(sunmi_yuk_price);
                oData.add(oItem);


                String sunmi_yuk_price1 = Integer.toString(sunmi_yuk_price);
                final String URL2 = "http://192.168.43.192:8080/web-study-02/list1_food2_sunmi.jsp";

                HttpClient client = new DefaultHttpClient();
                HttpPost post = new HttpPost(URL2);

                try {
                    nameValuePairs.add(new BasicNameValuePair("store_name3", sunmi_store_name));
                    nameValuePairs.add(new BasicNameValuePair("yuk_soup", sunmi_yuk_name));
                    nameValuePairs.add(new BasicNameValuePair("yuk_price", sunmi_yuk_price1));
                    nameValuePairs.add(new BasicNameValuePair("yuk_count", sunmi_yuk_count));
                    nameValuePairs.add(new BasicNameValuePair("id", id));
                    post.setEntity(new UrlEncodedFormEntity(nameValuePairs, "UTF-8"));

                    HttpParams params = client.getParams();

                    HttpResponse response = client.execute(post);
                } catch (Exception e) {
                    e.printStackTrace();
                    client.getConnectionManager().shutdown();
                }
            }
            if (sunmi_buda_name != null && total_num==1){
                oItem.strTitle = sunmi_store_name;
                oItem.strDate = sunmi_buda_name + sunmi_buda_count;
                price_list.add(sunmi_buda_price);
                oData.add(oItem);


                String sunmi_buda_price1 = Integer.toString(sunmi_buda_price);
                final String URL2 = "http://192.168.43.192:8080/web-study-02/list1_food2_sunmi.jsp";

                HttpClient client = new DefaultHttpClient();
                HttpPost post = new HttpPost(URL2);

                try {
                    nameValuePairs.add(new BasicNameValuePair("store_name3", sunmi_store_name));
                    nameValuePairs.add(new BasicNameValuePair("buda_soup", sunmi_buda_name));
                    nameValuePairs.add(new BasicNameValuePair("buda_price", sunmi_buda_price1));
                    nameValuePairs.add(new BasicNameValuePair("buda_count", sunmi_buda_count));
                    nameValuePairs.add(new BasicNameValuePair("id", id));
                    post.setEntity(new UrlEncodedFormEntity(nameValuePairs, "UTF-8"));

                    HttpParams params = client.getParams();

                    HttpResponse response = client.execute(post);
                } catch (Exception e) {
                    e.printStackTrace();
                    client.getConnectionManager().shutdown();
                }
            }
            if (chicken_coke_name != null && total_num==1){
                oItem.strTitle = chicken_store_name;
                oItem.strDate = chicken_coke_name + chicken_coke_count;
                price_list.add(chicken_coke_price);
                oData.add(oItem);


                String chicken_coke_price1 = Integer.toString(chicken_coke_price);
                final String URL = "http://192.168.43.192:8080/web-study-02/list1_food3_store.jsp";

                HttpClient client = new DefaultHttpClient();
                HttpPost post = new HttpPost(URL);

                try {
                    nameValuePairs.add(new BasicNameValuePair("name", chicken_store_name));
                    nameValuePairs.add(new BasicNameValuePair("chicken_coke", chicken_coke_name));
                    nameValuePairs.add(new BasicNameValuePair("coke_price", chicken_coke_price1));
                    nameValuePairs.add(new BasicNameValuePair("coke_count", chicken_coke_count));
                    nameValuePairs.add(new BasicNameValuePair("id", id));
                    post.setEntity(new UrlEncodedFormEntity(nameValuePairs, "UTF-8"));

                    HttpParams params = client.getParams();

                    HttpResponse response = client.execute(post);
                } catch (Exception e) {
                    e.printStackTrace();
                    client.getConnectionManager().shutdown();
                }
            }
            if (chicken_name != null && total_num==1){
                oItem.strTitle = chicken_store_name;
                oItem.strDate = chicken_name + chicken_count;
                price_list.add(chicken_price);
                oData.add(oItem);


                String chicken_price1 = Integer.toString(chicken_price);
                final String URL = "http://192.168.43.192:8080/web-study-02/list1_food3_store.jsp";

                HttpClient client = new DefaultHttpClient();
                HttpPost post = new HttpPost(URL);

                try {
                    nameValuePairs.add(new BasicNameValuePair("name", chicken_store_name));
                    nameValuePairs.add(new BasicNameValuePair("chicken", chicken_name));
                    nameValuePairs.add(new BasicNameValuePair("price", chicken_price1));
                    nameValuePairs.add(new BasicNameValuePair("count", chicken_count));
                    nameValuePairs.add(new BasicNameValuePair("id", id));
                    post.setEntity(new UrlEncodedFormEntity(nameValuePairs, "UTF-8"));

                    HttpParams params = client.getParams();

                    HttpResponse response = client.execute(post);
                } catch (Exception e) {
                    e.printStackTrace();
                    client.getConnectionManager().shutdown();
                }
            }
            if (chicken_spicy_name != null && total_num==1){
                oItem.strTitle = chicken_store_name;
                oItem.strDate = chicken_spicy_name + chicken_spicy_count;
                price_list.add(chicken_spicy_price);
                oData.add(oItem);


                String chicken_spicy_price1 = Integer.toString(chicken_spicy_price);
                final String URL = "http://192.168.43.192:8080/web-study-02/list1_food3_store.jsp";

                HttpClient client = new DefaultHttpClient();
                HttpPost post = new HttpPost(URL);

                try {
                    nameValuePairs.add(new BasicNameValuePair("name", chicken_store_name));
                    nameValuePairs.add(new BasicNameValuePair("chicken_spicy", chicken_spicy_name));
                    nameValuePairs.add(new BasicNameValuePair("spicy_price", chicken_spicy_price1));
                    nameValuePairs.add(new BasicNameValuePair("spicy_count", chicken_spicy_count));
                    nameValuePairs.add(new BasicNameValuePair("id", id));
                    post.setEntity(new UrlEncodedFormEntity(nameValuePairs, "UTF-8"));

                    HttpParams params = client.getParams();

                    HttpResponse response = client.execute(post);
                } catch (Exception e) {
                    e.printStackTrace();
                    client.getConnectionManager().shutdown();
                }
            }
            if (chicken_potato_name != null && total_num==1){
                oItem.strTitle = chicken_potato_name;
                oItem.strDate = chicken_potato_name + chicken_potato_count;
                price_list.add(chicken_potato_price);
                oData.add(oItem);


                String chicken_potato_price1 = Integer.toString(chicken_potato_price);
                final String URL = "http://192.168.43.192:8080/web-study-02/list1_food3_store.jsp";

                HttpClient client = new DefaultHttpClient();
                HttpPost post = new HttpPost(URL);

                try {
                    nameValuePairs.add(new BasicNameValuePair("name", chicken_store_name));
                    nameValuePairs.add(new BasicNameValuePair("potato", chicken_potato_name));
                    nameValuePairs.add(new BasicNameValuePair("potato_price", chicken_potato_price1));
                    nameValuePairs.add(new BasicNameValuePair("potato_count", chicken_potato_count));
                    nameValuePairs.add(new BasicNameValuePair("id", id));
                    post.setEntity(new UrlEncodedFormEntity(nameValuePairs, "UTF-8"));

                    HttpParams params = client.getParams();

                    HttpResponse response = client.execute(post);
                } catch (Exception e) {
                    e.printStackTrace();
                    client.getConnectionManager().shutdown();
                }
            }
            if (coffee_name != null && total_num==1){
                oItem.strTitle = coffee_store_name;
                oItem.strDate = coffee_name + coffee_count + coffee_ice;
                price_list.add(coffee_price);
                oData.add(oItem);


                String coffee_price1 = Integer.toString(coffee_price);
                final String URL = "http://192.168.43.192:8080/web-study-02/list1_caffe1_store.jsp";

                HttpClient client = new DefaultHttpClient();
                HttpPost post = new HttpPost(URL);

                try {
                    nameValuePairs.add(new BasicNameValuePair("cafe", coffee_store_name));
                    nameValuePairs.add(new BasicNameValuePair("coffee", coffee_name));
                    nameValuePairs.add(new BasicNameValuePair("coffee_price", coffee_price1));
                    nameValuePairs.add(new BasicNameValuePair("coffee_count", coffee_count));
                    nameValuePairs.add(new BasicNameValuePair("coffee_check", coffee_ice));
                    nameValuePairs.add(new BasicNameValuePair("id", id));
                    post.setEntity(new UrlEncodedFormEntity(nameValuePairs, "UTF-8"));

                    HttpParams params = client.getParams();

                    HttpResponse response = client.execute(post);
                } catch (Exception e) {
                    e.printStackTrace();
                    client.getConnectionManager().shutdown();
                }
            }
            if (coffee_latte_name != null && total_num==1){
                oItem.strTitle = coffee_store_name;
                oItem.strDate = coffee_latte_name + coffee_latte_count + coffee_latte_ice;
                price_list.add(coffee_latte_price);
                oData.add(oItem);


                String coffee_latte_price1 = Integer.toString(coffee_latte_price);
                final String URL = "http://192.168.43.192:8080/web-study-02/list1_caffe1_store.jsp";

                HttpClient client = new DefaultHttpClient();
                HttpPost post = new HttpPost(URL);

                try {
                    nameValuePairs.add(new BasicNameValuePair("cafe", coffee_store_name));
                    nameValuePairs.add(new BasicNameValuePair("latte", coffee_latte_name));
                    nameValuePairs.add(new BasicNameValuePair("latte_price", coffee_latte_price1));
                    nameValuePairs.add(new BasicNameValuePair("latte_count", coffee_latte_count));
                    nameValuePairs.add(new BasicNameValuePair("latte_check", coffee_latte_ice));
                    nameValuePairs.add(new BasicNameValuePair("id", id));
                    post.setEntity(new UrlEncodedFormEntity(nameValuePairs, "UTF-8"));

                    HttpParams params = client.getParams();

                    HttpResponse response = client.execute(post);
                } catch (Exception e) {
                    e.printStackTrace();
                    client.getConnectionManager().shutdown();
                }
            }
            if (coffee_moca_name != null && total_num==1){
                oItem.strTitle = coffee_store_name;
                oItem.strDate = coffee_moca_name + coffee_moca_count + coffee_moca_ice;
                price_list.add(coffee_moca_price);
                oData.add(oItem);


                String coffee_moca_price1 = Integer.toString(coffee_moca_price);
                final String URL = "http://192.168.43.192:8080/web-study-02/list1_caffe1_store.jsp";

                HttpClient client = new DefaultHttpClient();
                HttpPost post = new HttpPost(URL);

                try {
                    nameValuePairs.add(new BasicNameValuePair("cafe", coffee_store_name));
                    nameValuePairs.add(new BasicNameValuePair("moca", coffee_moca_name));
                    nameValuePairs.add(new BasicNameValuePair("moca_price", coffee_moca_price1));
                    nameValuePairs.add(new BasicNameValuePair("moca_count", coffee_moca_count));
                    nameValuePairs.add(new BasicNameValuePair("moca_check", coffee_moca_ice));
                    nameValuePairs.add(new BasicNameValuePair("id", id));
                    post.setEntity(new UrlEncodedFormEntity(nameValuePairs, "UTF-8"));

                    HttpParams params = client.getParams();

                    HttpResponse response = client.execute(post);
                } catch (Exception e) {
                    e.printStackTrace();
                    client.getConnectionManager().shutdown();
                }
            }
            if (coffee_capu_name != null && total_num==1){
                oItem.strTitle = coffee_store_name;
                oItem.strDate = coffee_capu_name + coffee_capu_count + coffee_capu_ice;
                price_list.add(coffee_capu_price);
                oData.add(oItem);

                String coffee_capu_price1 = Integer.toString(coffee_capu_price);
                final String URL = "http://192.168.43.192:8080/web-study-02/list1_caffe1_store.jsp";

                HttpClient client = new DefaultHttpClient();
                HttpPost post = new HttpPost(URL);

                try {
                    nameValuePairs.add(new BasicNameValuePair("cafe", coffee_store_name));
                    nameValuePairs.add(new BasicNameValuePair("capu", coffee_capu_name));
                    nameValuePairs.add(new BasicNameValuePair("capu_price", coffee_capu_price1));
                    nameValuePairs.add(new BasicNameValuePair("capu_count", coffee_capu_count));
                    nameValuePairs.add(new BasicNameValuePair("capu_check", coffee_capu_ice));
                    nameValuePairs.add(new BasicNameValuePair("id", id));
                    post.setEntity(new UrlEncodedFormEntity(nameValuePairs, "UTF-8"));

                    HttpParams params = client.getParams();

                    HttpResponse response = client.execute(post);
                } catch (Exception e) {
                    e.printStackTrace();
                    client.getConnectionManager().shutdown();
                }
            }
            if (hanyang_name != null && total_num==1){
                oItem.strTitle = hanyang_store_name;
                oItem.strDate = hanyang_name + hanyang_count;
                price_list.add(hanyang_price);
                oData.add(oItem);

                String hanyang_price1 = Integer.toString(hanyang_price);
                final String URL = "http://192.168.43.192:8080/web-study-02/list1_groceries1_1.jsp";

                HttpClient client = new DefaultHttpClient();
                HttpPost post = new HttpPost(URL);

                try {
                    nameValuePairs.add(new BasicNameValuePair("hanyang", hanyang_store_name));
                    nameValuePairs.add(new BasicNameValuePair("pork", hanyang_name));
                    nameValuePairs.add(new BasicNameValuePair("price", hanyang_price1));
                    nameValuePairs.add(new BasicNameValuePair("count", hanyang_count));


                    nameValuePairs.add(new BasicNameValuePair("id", id));
                    post.setEntity(new UrlEncodedFormEntity(nameValuePairs, "UTF-8"));

                    HttpParams params = client.getParams();

                    HttpResponse response = client.execute(post);
                } catch (Exception e) {
                    e.printStackTrace();
                    client.getConnectionManager().shutdown();
                }
            }
            if (hanyang_beef_name != null && total_num==1){
                oItem.strTitle = hanyang_store_name;
                oItem.strDate = hanyang_beef_name + hanyang_beef_count;
                price_list.add(hanyang_beef_price);
                oData.add(oItem);

                String hanyang_beef_price1 = Integer.toString(hanyang_beef_price);
                final String URL = "http://192.168.43.192:8080/web-study-02/list1_groceries1_1.jsp";

                HttpClient client = new DefaultHttpClient();
                HttpPost post = new HttpPost(URL);

                try {
                    nameValuePairs.add(new BasicNameValuePair("hanyang", hanyang_store_name));
                    nameValuePairs.add(new BasicNameValuePair("beef", hanyang_beef_name));
                    nameValuePairs.add(new BasicNameValuePair("beef_price", hanyang_beef_price1));
                    nameValuePairs.add(new BasicNameValuePair("beef_count", hanyang_count));

                    nameValuePairs.add(new BasicNameValuePair("id", id));
                    post.setEntity(new UrlEncodedFormEntity(nameValuePairs, "UTF-8"));

                    HttpParams params = client.getParams();

                    HttpResponse response = client.execute(post);
                } catch (Exception e) {
                    e.printStackTrace();
                    client.getConnectionManager().shutdown();
                }
            }
            if (hanyang_bul_name != null && total_num==1){
                oItem.strTitle = hanyang_store_name;
                oItem.strDate = hanyang_bul_name + hanyang_bul_count;
                price_list.add(hanyang_bul_price);
                oData.add(oItem);

                String hanyang_bul_price1 = Integer.toString(hanyang_bul_price);
                final String URL = "http://192.168.43.192:8080/web-study-02/list1_groceries1_1.jsp";

                HttpClient client = new DefaultHttpClient();
                HttpPost post = new HttpPost(URL);

                try {
                    nameValuePairs.add(new BasicNameValuePair("hanyang", hanyang_store_name));
                    nameValuePairs.add(new BasicNameValuePair("bulgogi", hanyang_bul_name));
                    nameValuePairs.add(new BasicNameValuePair("bul_price", hanyang_bul_price1));
                    nameValuePairs.add(new BasicNameValuePair("bul_count", hanyang_bul_count));

                    nameValuePairs.add(new BasicNameValuePair("id", id));
                    post.setEntity(new UrlEncodedFormEntity(nameValuePairs, "UTF-8"));

                    HttpParams params = client.getParams();

                    HttpResponse response = client.execute(post);
                } catch (Exception e) {
                    e.printStackTrace();
                    client.getConnectionManager().shutdown();
                }

            }
            if (hanyang_chicken_name != null && total_num==1){
                oItem.strTitle = hanyang_store_name;
                oItem.strDate = hanyang_chicken_name + hanyang_chicken_count;
                price_list.add(hanyang_chicken_price);
                oData.add(oItem);

                String hanyang_chicken_price1 = Integer.toString(hanyang_chicken_price);
                final String URL = "http://192.168.43.192:8080/web-study-02/list1_groceries1_1.jsp";

                HttpClient client = new DefaultHttpClient();
                HttpPost post = new HttpPost(URL);

                try {
                    nameValuePairs.add(new BasicNameValuePair("hanyang", hanyang_store_name));
                    nameValuePairs.add(new BasicNameValuePair("raw_chicken", hanyang_chicken_name));
                    nameValuePairs.add(new BasicNameValuePair("raw_price", hanyang_chicken_price1));
                    nameValuePairs.add(new BasicNameValuePair("raw_count", hanyang_chicken_count));
                    nameValuePairs.add(new BasicNameValuePair("id", id));
                    post.setEntity(new UrlEncodedFormEntity(nameValuePairs, "UTF-8"));

                    HttpParams params = client.getParams();

                    HttpResponse response = client.execute(post);
                } catch (Exception e) {
                    e.printStackTrace();
                    client.getConnectionManager().shutdown();
                }
            }
            if (singsing_cabbage_name != null && total_num==1){
                oItem.strTitle = singsing_store_name;
                oItem.strDate = singsing_cabbage_name + singsing_cabbage_count;
                price_list.add(singsing_cabbage_price);
                oData.add(oItem);

                String singsing_cabbage_price1 = Integer.toString(singsing_cabbage_price);
                final String URL = "http://192.168.43.192:8080/web-study-02/list1_groceries2_1.jsp";

                HttpClient client = new DefaultHttpClient();
                HttpPost post = new HttpPost(URL);

                try {
                    nameValuePairs.add(new BasicNameValuePair("singsing", singsing_store_name));
                    nameValuePairs.add(new BasicNameValuePair("cabbage", singsing_cabbage_name));
                    nameValuePairs.add(new BasicNameValuePair("price", singsing_cabbage_price1));
                    nameValuePairs.add(new BasicNameValuePair("count", singsing_cabbage_count));
                    nameValuePairs.add(new BasicNameValuePair("id", id));
                    post.setEntity(new UrlEncodedFormEntity(nameValuePairs, "UTF-8"));

                    HttpParams params = client.getParams();

                    HttpResponse response = client.execute(post);
                } catch (Exception e) {
                    e.printStackTrace();
                    client.getConnectionManager().shutdown();
                }
            }
            if (singsing_lettuce_name != null && total_num==1){
                oItem.strTitle = singsing_store_name;
                oItem.strDate =singsing_lettuce_name + singsing_lettuce_count;
                price_list.add(singsing_lettuce_price);
                oData.add(oItem);

                String singsing_lettuce_price1 = Integer.toString(singsing_lettuce_price);
                final String URL = "http://192.168.43.192:8080/web-study-02/list1_groceries2_1.jsp";

                HttpClient client = new DefaultHttpClient();
                HttpPost post = new HttpPost(URL);

                try {
                    nameValuePairs.add(new BasicNameValuePair("singsing", singsing_store_name));
                    nameValuePairs.add(new BasicNameValuePair("lettuce", singsing_lettuce_name));
                    nameValuePairs.add(new BasicNameValuePair("l_price", singsing_lettuce_price1));
                    nameValuePairs.add(new BasicNameValuePair("l_count", singsing_lettuce_count));
                    nameValuePairs.add(new BasicNameValuePair("id", id));
                    post.setEntity(new UrlEncodedFormEntity(nameValuePairs, "UTF-8"));

                    HttpParams params = client.getParams();

                    HttpResponse response = client.execute(post);
                } catch (Exception e) {
                    e.printStackTrace();
                    client.getConnectionManager().shutdown();
                }
            }
            if (singsing_raddish_name != null && total_num==1){
                oItem.strTitle = singsing_store_name;
                oItem.strDate = singsing_raddish_name + singsing_raddish_count;
                price_list.add(singsing_raddish_price);
                oData.add(oItem);

                String singsing_raddish_price1 = Integer.toString(singsing_raddish_price);
                final String URL = "http://192.168.43.192:8080/web-study-02/list1_groceries2_1.jsp";

                HttpClient client = new DefaultHttpClient();
                HttpPost post = new HttpPost(URL);

                try {
                    nameValuePairs.add(new BasicNameValuePair("singsing", singsing_store_name));
                    nameValuePairs.add(new BasicNameValuePair("raddish", singsing_raddish_name));
                    nameValuePairs.add(new BasicNameValuePair("r_price", singsing_raddish_price1));
                    nameValuePairs.add(new BasicNameValuePair("r_count", singsing_raddish_count));
                    nameValuePairs.add(new BasicNameValuePair("id", id));
                    post.setEntity(new UrlEncodedFormEntity(nameValuePairs, "UTF-8"));

                    HttpParams params = client.getParams();

                    HttpResponse response = client.execute(post);
                } catch (Exception e) {
                    e.printStackTrace();
                    client.getConnectionManager().shutdown();
                }
            }
            if (singsing_cucumber_name != null && total_num==1){
                oItem.strTitle = singsing_store_name;
                oItem.strDate = singsing_cucumber_name + singsing_cucumber_count;
                price_list.add(singsing_cucumber_price);
                oData.add(oItem);

                String singsing_cucumber_price1 = Integer.toString(singsing_cucumber_price);
                final String URL = "http://192.168.43.192:8080/web-study-02/list1_groceries2_1.jsp";

                HttpClient client = new DefaultHttpClient();
                HttpPost post = new HttpPost(URL);

                try {
                    nameValuePairs.add(new BasicNameValuePair("singsing", singsing_store_name));
                    nameValuePairs.add(new BasicNameValuePair("cucumber", singsing_cucumber_name));
                    nameValuePairs.add(new BasicNameValuePair("c_price", singsing_cucumber_price1));
                    nameValuePairs.add(new BasicNameValuePair("c_count", singsing_cucumber_count));
                    nameValuePairs.add(new BasicNameValuePair("id", id));
                    post.setEntity(new UrlEncodedFormEntity(nameValuePairs, "UTF-8"));

                    HttpParams params = client.getParams();

                    HttpResponse response = client.execute(post);
                } catch (Exception e) {
                    e.printStackTrace();
                    client.getConnectionManager().shutdown();
                }
            }

            if (total_price == 0) {
                total_price += price_list.get(0);

            } else {
                total_price += price_list.get(price_list.size() - 1);

            }
            super.onBackPressed();
        } else {
            textView_price.setText("결제금액 : " + +total_price + "원");
            Button button_back = (Button) findViewById(R.id.button13);
            Button button1 = (Button) findViewById(R.id.button_next); //결제버튼
            button1.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    checkBox.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            Checked(v);
                            btn_checked = Checked(v);
                                 }
                    });
                    if (oData.size() == 0){
                        Toast.makeText(MainActivity_shopping.this, "장바구니가 비어있습니다. 물건을 담아주세요!", Toast.LENGTH_SHORT).show();
                    }
                    else {
                        intent2 = new Intent(getApplicationContext(), MainActivity_tool_of_payment.class);
                        intent2.putExtra("togo", btn_checked);
                        startActivity(intent2);
                    }
                }
            });

        }


        deleteall_button = (Button) findViewById(R.id.deleteall);  //삭제버튼
        deleteall_button.setOnClickListener(new Button.OnClickListener() {
            public void onClick(View v) {
                oData.clear();
                listview1.setAdapter(null);
                total_price = 0;
                price_list.clear();
                textView_price.setText("결제금액 : " + +total_price + "원");
                Toast.makeText(MainActivity_shopping.this, "삭제되었습니다.", Toast.LENGTH_SHORT).show();
                 // 모든 선택 상태 초기화.
                listview1.clearChoices();
                oAdapter.notifyDataSetChanged();
            }
        });


    }
    public String Checked(View v) {
        CheckBox checkBox1 = (CheckBox) findViewById(R.id.checkBox2);

        String resultText = "";
        if(checkBox1.isChecked()) {
            resultText = "전체포장";
        }

        return resultText;
    }
}
