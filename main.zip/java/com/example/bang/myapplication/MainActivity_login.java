package com.example.bang.myapplication;

import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity_login extends AppCompatActivity {
    String id_string;
    String pw_string;
    EditText id;
    EditText pw;
    SQLiteDatabase database;
    int num=0;
    //boolean login_bool;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_login);


        Button button_signup = (Button)findViewById(R.id.signUpButton);
        button_signup.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                Intent intent_signup = new Intent(getApplicationContext(),activity_join.class);
                startActivity(intent_signup);
            }

        });

        Button button_login = (Button)findViewById(R.id.loginButton);
        button_login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                num=1;
                Intent intent_login = new Intent(getApplicationContext(),MainActivity_menu.class);
                intent_login.putExtra("login_num", num);
                startActivity(intent_login);
                Toast.makeText(MainActivity_login.this, "로그인 되었습니다.", Toast.LENGTH_SHORT).show();

            }
        });

    }
}
