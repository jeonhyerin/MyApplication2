package com.example.bang.myapplication;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity_food extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_food);

       /* final TextView id_textView = (TextView)findViewById(R.id.id);
        Bundle intent_id = getIntent().getExtras();
        id_textView.setText(intent_id.getString("id"));*/


        Button button1 = (Button)findViewById(R.id.button7);
        Button button_back = (Button)findViewById(R.id.button13);
        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), MainActivity_food1_store.class);
                //intent.putExtra("id", id_textView.getText().toString());
                startActivity(intent);
            }
        });

        Button button2 = (Button)findViewById(R.id.button8);
        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent2 = new Intent(getApplicationContext(),MainActivity_food2_store.class);
                startActivity(intent2);
            }
        });

        Button button3 = (Button)findViewById(R.id.button10);
        button3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent3 = new Intent(getApplicationContext(),MainActivity_food3_store.class);
                startActivity(intent3);
            }
        });


    }
}
