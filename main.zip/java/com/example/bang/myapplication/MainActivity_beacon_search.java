package com.example.bang.myapplication;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity_beacon_search extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_beacon_search);

        LinearLayout ll = new LinearLayout(this);
        TextView tv = new TextView(this);
        tv.setText("Hello World");
        ll.addView(tv);
        setContentView(ll);
    }
}
