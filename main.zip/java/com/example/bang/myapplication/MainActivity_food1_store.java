package com.example.bang.myapplication;

import android.content.Intent;
import android.os.Build;
import android.os.StrictMode;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.params.HttpParams;

import java.util.ArrayList;
import java.util.HashMap;

public class MainActivity_food1_store extends AppCompatActivity {

    String store_name = "";
    String store_name2 = "";
    String store_name3 = "";
    String store_name4 = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_food1_store);

        if (Build.VERSION.SDK_INT > 9) {
            StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();

            StrictMode.setThreadPolicy(policy);

        }
        SessionManager session = new SessionManager(getApplicationContext());
        HashMap<String, String> user = session.getUserDetails();

        final String id = user.get(SessionManager.KEY_ID);

        final String URL = "http://192.168.43.192:8080/web-study-02/list1_food1_unnine.jsp"; // 언니네 jsp 서버
        final String URL1 = "http://192.168.43.192:8080/web-study-02/list1_food1_garlictoppoki.jsp"; // 마늘떡볶이 jsp 서버
        final String URL2 = "http://192.168.43.192:8080/web-study-02/list1_food1_lilane.jsp"; // 리라네분식 jsp 서버

        final Button button1 = (Button)findViewById(R.id.button_1);
        store_name = button1.getText().toString() + "  ";
        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                HttpPost post = new HttpPost(URL);
                HttpClient client = new DefaultHttpClient();
                if(v == button1) {
                    try {
                        ArrayList<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>();
                        nameValuePairs.add(new BasicNameValuePair("store_name", store_name));
                        nameValuePairs.add(new BasicNameValuePair("id", id));
                        post.setEntity(new UrlEncodedFormEntity(nameValuePairs, "UTF-8"));

                        HttpParams params = client.getParams();

                        HttpResponse response = client.execute(post);
                    } catch (Exception e) {
                        e.printStackTrace();
                        client.getConnectionManager().shutdown();
                    }

                }
                Intent intent = new Intent(getApplicationContext(),MainActivity_unnine.class);
                intent.putExtra("name", store_name);
                startActivity(intent);
            }
        });

        final Button button2 = (Button)findViewById(R.id.button_2);
        store_name2 = button2.getText().toString() + "  ";
        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                HttpClient client = new DefaultHttpClient();
                HttpPost post = new HttpPost(URL1);

                if(v == button2) {
                    try {
                        ArrayList<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>();
                        nameValuePairs.add(new BasicNameValuePair("store_name2", store_name2));
                        nameValuePairs.add(new BasicNameValuePair("id", id));
                        post.setEntity(new UrlEncodedFormEntity(nameValuePairs, "UTF-8"));

                        HttpParams params = client.getParams();

                        HttpResponse response = client.execute(post);
                    } catch (Exception e) {
                        e.printStackTrace();
                        client.getConnectionManager().shutdown();
                    }

                }
                Intent intent = new Intent(getApplicationContext(),MainActivity_garlictoppoki.class);
                intent.putExtra("name", store_name2);
                startActivity(intent);
            }
        });

        final Button button3 = (Button)findViewById(R.id.button_3);
        store_name3 = button3.getText().toString() + "  ";
        button3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                HttpClient client = new DefaultHttpClient();
                HttpPost post = new HttpPost(URL2);

                if(v == button3) {
                    try {
                        ArrayList<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>();
                        nameValuePairs.add(new BasicNameValuePair("store_name3", store_name3));
                        nameValuePairs.add(new BasicNameValuePair("id", id));
                        post.setEntity(new UrlEncodedFormEntity(nameValuePairs, "UTF-8"));

                        HttpParams params = client.getParams();

                        HttpResponse response = client.execute(post);
                    } catch (Exception e) {
                        e.printStackTrace();
                        client.getConnectionManager().shutdown();
                    }

                }
                Intent intent = new Intent(getApplicationContext(),MainActivity_lilane.class);
                intent.putExtra("name", store_name3);
                startActivity(intent);
            }
        });

        Button button_rice = (Button)findViewById(R.id.button4);
        button_rice.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(),MainActivity_food2_store.class);
                startActivity(intent);
            }
        });

        Button button_chicken = (Button)findViewById(R.id.button5);
        button_chicken.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(),MainActivity_food3_store.class);
                startActivity(intent);
            }
        });
    }
}
