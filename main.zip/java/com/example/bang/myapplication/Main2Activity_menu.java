package com.example.bang.myapplication;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Typeface;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;

import com.estimote.sdk.Beacon;
import com.estimote.sdk.BeaconManager;
import com.estimote.sdk.Region;
import com.estimote.sdk.SystemRequirementsChecker;

import java.util.List;
import java.util.UUID;

public class Main2Activity_menu extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2_menu);
        //Typeface typeFace = Typeface.createFromAsset(getAssets(), "NanumBarunpenRegular.otf");
        TextView tv = (TextView) findViewById(R.id.tv);
        //tv.setTypeface(typeFace);
        tv.setSelected(true);

        Button button_food = (Button) findViewById(R.id.button_food);
        button_food.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), MainActivity_food.class);
                //intent.putExtra("id", textView.getText().toString());
                startActivity(intent);
            }
        });
        Button button_cafe = (Button) findViewById(R.id.button_cafe);
        button_cafe.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), MainActivity_caffe1_store.class);
                //intent.putExtra("id", textView.getText().toString());
                startActivity(intent);
            }
        });

        Button button_vege = (Button) findViewById(R.id.button_vegetable);
        button_vege.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), MainActivity_groceries1_store.class);
                //intent.putExtra("id", textView.getText().toString());
                startActivity(intent);
            }
        });


    }


}

