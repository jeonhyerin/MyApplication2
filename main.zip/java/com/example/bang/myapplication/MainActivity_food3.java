package com.example.bang.myapplication;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity_food3 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_food3);

        Button b1 = (Button)findViewById(R.id.toppoki);
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(),MainActivity_food3_chicken.class);
                startActivity(intent);
            }
        });

        Button b2 = (Button)findViewById(R.id.sundae);
        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(),MainActivity_food3_spicy_chicken.class);
                startActivity(intent);
            }
        });

        Button b3 = (Button)findViewById(R.id.friedfood);
        b3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(),MainActivity_food3_fried_potato.class);
                startActivity(intent);
            }
        });

        Button b4 = (Button)findViewById(R.id.ricefish);
        b4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(),MainActivity_food3_beverage.class);
                startActivity(intent);
            }
        });
    }
}
