package com.example.bang.myapplication;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity_hanyang_chinese extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_hanyang_chinese);

        Button button_pork = (Button)findViewById(R.id.pork);
        button_pork.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(),MainActivity_groceries1_pork_chinese.class);
                startActivity(intent);
            }
        });
        Button button_bulgogi = (Button)findViewById(R.id.bulgogi);
        button_bulgogi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(),MainActivity_groceries1_bulgogi_chinese.class);
                startActivity(intent);
            }
        });
    }
}