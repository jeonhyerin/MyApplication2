package com.example.bang.myapplication;

import android.content.Intent;
import android.os.Build;
import android.os.StrictMode;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.params.HttpParams;

import java.util.ArrayList;
import java.util.HashMap;

public class MainActivity_groceries1_store extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_groceries1_store);

        if (Build.VERSION.SDK_INT > 9) {
            StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();

            StrictMode.setThreadPolicy(policy);

        }
        SessionManager session = new SessionManager(getApplicationContext());
        HashMap<String, String> user = session.getUserDetails();

        final String id = user.get(SessionManager.KEY_ID);

        final String URL = "http://192.168.43.192:8080/web-study-02/list1_groceries1_1.jsp";
        final Button button1 = (Button)findViewById(R.id.button_1);
        final String store_name = button1.getText().toString() + "  ";
        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                HttpPost post = new HttpPost(URL);
                HttpClient client = new DefaultHttpClient();
                if(v == button1) {
                    try {
                        ArrayList<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>();
                        nameValuePairs.add(new BasicNameValuePair("hanyang", store_name));
                        nameValuePairs.add(new BasicNameValuePair("id", id));
                        post.setEntity(new UrlEncodedFormEntity(nameValuePairs, "UTF-8"));

                        HttpParams params = client.getParams();

                        HttpResponse response = client.execute(post);
                    } catch (Exception e) {
                        e.printStackTrace();
                        client.getConnectionManager().shutdown();
                    }

                }
                Intent intent = new Intent(getApplicationContext(),MainActivity_hanyang.class);
                startActivity(intent);
            }
        });

        Button b_1 = (Button)findViewById(R.id.button4);
        b_1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(),MainActivity_groceries2_store.class);
                startActivity(intent);
            }
        });
    }
}
